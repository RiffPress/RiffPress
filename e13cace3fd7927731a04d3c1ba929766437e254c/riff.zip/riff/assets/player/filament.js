/* The filament. The played part of the bar's seek line is a wire with current in it. The script
 * keeps one number, its heat, and writes it to --riff-heat on the lines once a frame; the stylesheet
 * turns that into the opacity of each fixed-colour layer of its light, which the GPU composites
 * without painting anything again. The heat follows a filament's physics: the signal's power drives
 * it up in about 80 ms, and with the current cut it cools the way a hot thing does, fast while it is
 * bright, then slowly through a long red tail. What counts as full power is whatever the track has
 * been reaching lately, so a quiet recording and a loud mix each light the whole wire. Where there
 * is no analyser (iOS, a file from another origin) the wire breathes at working temperature
 * instead. Loaded on demand, when the first track does. */

export default function filament( P ) {
	const { root, $, $$, audio, own } = P;
	const wire = $( '[data-riff-wire]' );
	const heart = $( '[data-riff-hot]' );
	const isIOS =
		/iP(hone|ad|od)/.test( navigator.userAgent ) ||
		( navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1 );
	P.analyser = null;
	let samples = null;
	let bins = null;
	let meterRaf = 0;
	// The loop is parked, not stopped, while nothing it lights is in sight: see seen().
	let parked = false;
	let breath = null;
	let bars = [];
	let cooling = false;
	let lastTick = 0;
	// The wire's state outlives a restart: a view swap or a row appearing never dips it, and the
	// reference never has to relearn the track.
	let heat = 0;
	let ref = 0.08;

	// Routing audio through Web Audio on iOS breaks lock-screen and background playback, so iPhones
	// keep the breath. A file from another origin cannot be analysed either; see foreign().
	function ensureAnalyser() {
		const t = P.track();
		// Only once <audio> holds a file Web Audio may hear: its own origin's, or one loaded for
		// CORS. One from another origin loaded before that origin said yes would play as silence.
		const file = audio.currentSrc || audio.getAttribute( 'src' ) || '';
		const readable =
			! file ||
			new URL( file, location.href ).origin === location.origin ||
			audio.crossOrigin === 'anonymous';
		if (
			P.analyser ||
			isIOS ||
			! window.AudioContext ||
			! t ||
			P.foreign( t ) ||
			! readable
		) {
			return;
		}
		try {
			const ctx = new AudioContext();
			const src = ctx.createMediaElementSource( audio );
			const analyser = ctx.createAnalyser();
			// A 1024-sample window is 20 ms at 48 kHz: long enough for a steady RMS, short enough
			// to catch a transient.
			analyser.fftSize = 1024;
			analyser.smoothingTimeConstant = 0.6;
			samples = new Float32Array( analyser.fftSize );
			bins = new Uint8Array( analyser.frequencyBinCount );
			src.connect( analyser );
			analyser.connect( ctx.destination );
			audio.addEventListener( 'play', () =>
				ctx.resume().catch( () => {} )
			);
			// Suspended while nothing plays: the graph stops pulling samples, and the filament's
			// cool-down reads silence, which is right.
			for ( const ev of [ 'pause', 'ended' ] ) {
				audio.addEventListener( ev, () =>
					ctx.suspend().catch( () => {} )
				);
			}
			ctx.resume().catch( () => {} );
			P.analyser = analyser;
		} catch {
			P.analyser = null;
		}
	}

	// The signal's level: RMS over the window, as a filament sees current.
	function level() {
		P.analyser.getFloatTimeDomainData( samples );
		let sum = 0;
		for ( let n = 0; n < samples.length; n++ ) {
			sum += samples[ n ] * samples[ n ];
		}
		return Math.sqrt( sum / samples.length );
	}

	// Three bands for the bars on the playing row: bass, the body of a voice, and the air above it.
	const BANDS = [
		[ 1, 4 ],
		[ 4, 22 ],
		[ 22, 110 ],
	];
	// Each band is read against its own recent range, the way the wire reads against its own
	// reference: bass carries the most energy in nearly any mix, so one scale for all three pins
	// the bass bar and leaves the treble low, a staircase that barely moves. The range's top
	// follows a hit at once and settles over three seconds; its floor drops at once and climbs over
	// one, so a quiet intro doesn't hold every bar at the top for long. Each bar spends its whole
	// height on the band's own swing. A bar then rises fast and falls slower,
	// as a meter does, so a hit reads as a hit.
	const bands = BANDS.map( () => ( { lo: -1, hi: 0, shown: 0 } ) );
	const ease = ( from, to, dt, tau ) =>
		from + ( to - from ) * ( 1 - Math.exp( -dt / tau ) );
	function bandLevels( dt ) {
		P.analyser.getByteFrequencyData( bins );
		return BANDS.map( ( [ a, b ], k ) => {
			let sum = 0;
			for ( let n = a; n < b; n++ ) {
				sum += bins[ n ];
			}
			const v = sum / ( b - a ) / 255;
			const band = bands[ k ];
			if ( band.lo < 0 ) {
				band.lo = band.hi = v;
			}
			band.hi = ease( band.hi, v, dt, v > band.hi ? 0.03 : 3 );
			band.lo = ease( band.lo, v, dt, v < band.lo ? 0.03 : 1 );
			const at = Math.min(
				1,
				Math.max(
					0,
					( v - band.lo ) / Math.max( 0.06, band.hi - band.lo )
				)
			);
			band.shown = ease(
				band.shown,
				at,
				dt,
				at > band.shown ? 0.04 : 0.2
			);
			return band.shown;
		} );
	}

	// One step of the wire's physics. drive is the current, 0 to a little over 1; dt is in seconds.
	// Heating chases the drive with a 120 ms time constant: a wire warms, it does not flash.
	// Cooling is radiation plus conduction: a heat⁴ term that empties it while it is bright, and a
	// slow linear term for the tail, so a loud passage settles in half a second and the last red
	// takes a couple of seconds.
	function advance( drive, dt ) {
		if ( drive > heat ) {
			heat += ( drive - heat ) * ( 1 - Math.exp( -dt / 0.12 ) );
		} else {
			const loss = heat / 0.8 + 2.2 * heat * heat * heat * heat;
			heat = Math.max( drive, heat - loss * dt );
		}
		heat = Math.min( 1.2, heat );
	}

	// The wire is seen, not measured: a square root lifts the quiet end into view, since speech
	// sits around a tenth of full scale and would otherwise read as unlit.
	// Written on the lines and the glow themselves, not the root: a property on the root restyles
	// every element in the player each frame, these three restyle three. Only where it is seen, Now
	// Playing's line and glow only while it is open, and only when the value moves by a step the eye
	// could see: an unchanged write still costs the frame a restyle.
	const heated = $$( '.riff-line, .riff-np-glow' ).map( ( node ) => ( {
		node,
		inNowPlaying: !! node.closest( '.riff-np' ),
		last: '',
	} ) );
	function setHeat( h ) {
		const value = Math.sqrt( Math.min( 1, Math.max( 0, h ) ) ).toFixed( 2 );
		for ( const spot of heated ) {
			if ( spot.last === value || ( spot.inNowPlaying && P.np.hidden ) ) {
				continue;
			}
			spot.last = value;
			spot.node.style.setProperty( '--riff-heat', value );
		}
	}

	// The meter area: each frame's heat and bands go to Riff's own listeners (own.meter), the
	// wire's glow and the playing row's bars among them. levels is null while the wire cools.
	const hear = ( h, levels = null ) =>
		own.meter.forEach( ( fn ) => fn( { heat: h, levels } ) );
	own.meter.add( ( { heat: h } ) => setHeat( h ) );
	// Three bars per place the current track is shown: the row in the post and the item in Up
	// next. Each place's bars take the three bands in turn. Only the places on screen are written,
	// and only by a step the eye could see: each write restyles the bar and its neighbours.
	// The lines and the glow are watched too, so that when none of them and no place is in sight
	// (the bar hidden, Now Playing closed, the row scrolled away) the loop parks until one is.
	// Hidden is out of sight as well: a hidden element never intersects.
	const onScreen = new Set();
	const watch =
		'IntersectionObserver' in window
			? new IntersectionObserver( ( entries ) => {
				for ( const e of entries ) {
					onScreen[ e.isIntersecting ? 'add' : 'delete' ]( e.target );
				}
				wake();
			} )
			: null;
	let places = [];
	heated.forEach( ( spot ) => watch?.observe( spot.node ) );
	const seen = () => ! watch || onScreen.size > 0;
	function wake() {
		if ( parked && seen() ) {
			parked = false;
			lastTick = 0;
			meterRaf = requestAnimationFrame( tick );
		}
	}
	const looping = () => meterRaf || parked;
	own.meter.add( ( { levels } ) => {
		if ( ! levels ) {
			return;
		}
		bars.forEach( ( bar, k ) => {
			if ( watch && ! onScreen.has( bar.parentNode ) ) {
				return;
			}
			const height = 0.15 + 0.85 * levels[ k % levels.length ];
			const scale = `scaleY(${ ( Math.round( height * 20 ) / 20 ).toFixed( 2 ) })`;
			// Unchanged, it is left alone: a write costs a restyle even when it says the same.
			if ( bar.style.transform !== scale ) {
				bar.style.transform = scale;
			}
		} );
	} );

	const liveBars = () => {
		const found = [
			...document.querySelectorAll(
				'.riff-row[data-current] .riff-row-state i, .riff-queue-list [aria-current] .riff-row-state i'
			),
		];
		const next = [ ...new Set( found.map( ( bar ) => bar.parentNode ) ) ];
		// Watched anew only when the places change, as each paint asks again.
		if ( watch && ( next.length !== places.length || next.some( ( place, k ) => place !== places[ k ] ) ) ) {
			for ( const place of places ) {
				watch.unobserve( place );
				onScreen.delete( place );
			}
			places = next;
			places.forEach( ( place ) => watch.observe( place ) );
		}
		return found;
	};

	function tick( now = 0 ) {
		const dt = lastTick
			? Math.min( 0.1, ( now - lastTick ) / 1000 )
			: 0.016;
		lastTick = now;
		// Nothing it lights is in sight: the loop parks, and the observer wakes it. A wire cooling
		// unseen is dark by the time it is seen again.
		if ( ! seen() ) {
			meterRaf = 0;
			if ( cooling ) {
				cooling = false;
				heat = 0;
				hear( 0 );
			} else {
				parked = true;
			}
			return;
		}
		if ( cooling ) {
			advance( 0, dt );
			hear( heat );
			if ( heat > 0.004 ) {
				meterRaf = requestAnimationFrame( tick );
			} else {
				heat = 0;
				hear( 0 );
				meterRaf = 0;
				cooling = false;
			}
			return;
		}
		const rms = level();
		// The reference rises to a peak in about 150 ms and forgets it over six seconds: a surge
		// flashes past full for a moment, as it would, and the wire ranges itself to the material.
		ref +=
			( rms - ref ) * ( 1 - Math.exp( -dt / ( rms > ref ? 0.15 : 6 ) ) );
		advance( rms / Math.max( 0.02, ref ), dt );
		hear( heat, bandLevels( dt ) );
		meterRaf = requestAnimationFrame( tick );
	}

	// Cut the current: the loop keeps running with no drive until the wire is dark.
	function meterStop() {
		if ( ! looping() && ! breath ) {
			return;
		}
		breath?.cancel();
		breath = null;
		root.removeAttribute( 'data-live' );
		for ( const bar of bars ) {
			bar.style.transform = '';
		}
		bars = [];
		// Out at once where the wire cooling would not be seen.
		if ( P.reduce() || P.away() ) {
			cancelAnimationFrame( meterRaf );
			meterRaf = 0;
			parked = false;
			heat = 0;
			hear( 0 );
			return;
		}
		cooling = true;
		if ( ! meterRaf ) {
			parked = false;
			lastTick = 0;
			meterRaf = requestAnimationFrame( tick );
		}
	}

	function meterStart() {
		cooling = false;
		if ( P.reduce() ) {
			cancelAnimationFrame( meterRaf );
			meterRaf = 0;
			parked = false;
			hear( 0.25 );
			return;
		}
		ensureAnalyser();
		if ( ! P.analyser || P.el() !== audio || ! wire ) {
			cancelAnimationFrame( meterRaf );
			meterRaf = 0;
			parked = false;
			heat = 0.5;
			hear( heat );
			breath = heart.animate(
				[ { opacity: 0 }, { opacity: 0.45 }, { opacity: 0 } ],
				{
					duration: 2600,
					iterations: Infinity,
					easing: 'ease-in-out',
				}
			);
			return;
		}
		root.dataset.live = '';
		bars = rest( liveBars() );
		if ( ! meterRaf ) {
			parked = false;
			lastTick = 0;
			meterRaf = requestAnimationFrame( tick );
		}
	}

	// A new track's bars start from rest, each band's range from nothing: the last track's levels
	// are not this one's, and would flash on the new row before the new song is heard.
	let barsFor = null;
	function rest( next ) {
		for ( const bar of bars ) {
			bar.style.transform = '';
		}
		for ( const band of bands ) {
			Object.assign( band, { lo: -1, hi: 0, shown: 0 } );
		}
		for ( const bar of next ) {
			bar.style.transform = 'scaleY(0.15)';
		}
		return next;
	}

	// Called from paint(): the wire follows whatever is playing, and the bars follow the current row.
	function meterSync() {
		const t = P.track();
		if ( t && ! P.el().paused && ! P.away() ) {
			if ( ( ! looping() || cooling ) && ! breath ) {
				meterStart();
			} else if ( looping() ) {
				bars = barsFor === t ? liveBars() : rest( liveBars() );
			}
			barsFor = t;
		} else {
			meterStop();
		}
	}

	P.meterSync = meterSync;
	// Loaded while something may already be playing: the wire catches up at once.
	meterSync();
	return { meterSync };
}
