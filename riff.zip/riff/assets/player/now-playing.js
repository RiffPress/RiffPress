/* Now Playing. A dialog over the page: the page goes inert, Escape and the browser's back close
 * it, and focus goes back where it was. It is the track on its own: Up next and the other panels
 * are their own things, opened beside it or over it (registry.js). Where its album is the
 * turntable, the deck is all there is on the screen (immerse()). Its background takes its colour
 * from the artwork, darkened so text stays legible. The record beside the cover is cut as an LP
 * is: a band of grooves for each of the album's tracks, as wide as the track is long. It turns at
 * 33⅓, faster or slower with the music's speed as a turntable's pitch would, and its tonearm
 * tracks the album from the outside in. */
import { average, coverAccent, hsl, largest, route, time } from 'riff-player/helpers';

// Strings are WordPress translations of this module (wp_set_script_module_translations()).
// Core prints wp.i18n only when there are translations, so without it the strings are the
// English they are written in.
const __ = window.wp?.i18n?.__ || ( ( english ) => english );

export function nowPlaying( P ) {
	const { root, np, $, $$ } = P;
	// Whether the hand set the arm down off the record, on its rest (put()), so a start carries it
	// back over the groove before the lever lowers it.
	let rested = false;

	let opener = null;
	// The view showing: the album, the stage, until the listener opens another.
	P.showing = 'album';
	const screen = ( id ) => P.views?.get( id )?.place === 'screen';

	// A view in Now Playing's place: its region shown and the others hidden, or the stage for the
	// album, the record out on the deck where Now Playing is landscape and the cover on its own
	// where it is portrait (roomy()).
	function setView( id ) {
		if ( ! screen( id ) ) {
			return;
		}
		const was = P.showing;
		const shown = ! np.hidden;
		P.showing = id;
		root.dataset.riffShowing = id;
		const stage = !! P.views.get( id ).stage;
		np.dataset.riffScreen = stage ? 'stage' : 'own';
		for ( const [ other, v ] of P.views ) {
			if ( v.place === 'screen' && v.el ) {
				v.el.hidden = other !== id;
			}
		}
		roomy.last = undefined;
		clearTimeout( deck.opening );
		// Not a press of the listener's: changing the view doesn't stop following someone.
		retune( false );
		markRoom();
		deck( roomy() && ( 'riffTurning' in root.dataset || wholeDeck() ) );
		if ( shown && was !== id ) {
			P.viewOpened?.( was, false );
		}
		if ( shown ) {
			P.viewOpened?.( id, true );
			focusView();
		}
		P.drawControls?.();
		P.wakeControls?.();
	}

	// Focus into the view: its own region, or Now Playing's close button for the stage.
	function focusView() {
		const own = P.views?.get( P.showing );
		( own && ! own.stage && own.el ? own.el : $( '[data-riff-action="close"]' ) )?.focus( {
			preventScroll: true,
		} );
	}

	// A theme's viewport rarely reaches into a phone's notch and corners (viewport-fit), so Safari
	// letterboxes the page in the theme's colour, a white strip beside the deck on a phone on its
	// side. While Now Playing is open the page reaches them, and Now Playing keeps its controls
	// clear of them (riff.css's safe areas); closed, the theme's viewport is as it was.
	const viewport = document.querySelector( 'meta[name="viewport"]' );
	const themed = viewport?.getAttribute( 'content' ) || '';
	function reach( edges ) {
		if ( ! viewport || /viewport-fit/.test( themed ) ) {
			return;
		}
		viewport.setAttribute(
			'content',
			edges ? [ themed, 'viewport-fit=cover' ].filter( Boolean ).join( ', ' ) : themed
		);
	}

	function open( id ) {
		if ( ! P.track() ) {
			return;
		}
		// Open, and not sliding away: the view changes in place.
		if ( ! np.hidden && root.classList.contains( 'is-open' ) ) {
			setView( screen( id ) ? id : 'album' );
			return;
		}
		const view = screen( id ) ? id : 'album';
		// Safari doesn't focus a button on click, so after a click the active element is the body;
		// focus then goes back to the view's button in the bar.
		const active = document.activeElement;
		opener =
			active && active !== document.body
				? active
				: $( `[data-riff-control="${ view }"]` ) || $( '.riff-bar-info' );
		setView( view );
		// Opened again while it slid away: it stays.
		clearTimeout( closing.timer );
		np.removeEventListener( 'transitionend', closing.done );
		closing.done = null;
		np.hidden = false;
		root.classList.add( 'is-open' );
		reach( true );
		P.syncWakeLock?.();
		// Everything but the dialog is inert: the rest of the page, and on a phone the player's own
		// bar and toast, which the dialog covers there and which would otherwise still take focus.
		// On a wide screen the dialog opens above the bar and the bar stays the control surface,
		// unless it is a touch screen on its side, where Now Playing covers the bar as a phone's
		// does, the turntable or not, or the deck on its own, which has the whole window (riff.css).
		coverPage();
		immerse();
		history.pushState( { ...history.state, riff: 'open' }, '' );
		P.viewOpened?.( view, true );
		P.drawControls?.();
		P.wakeControls?.();
		requestAnimationFrame( () => {
			np.classList.add( 'is-in' );
			focusView();
			if ( P.reduce() ) {
				hidePage();
			} else {
				np.addEventListener( 'transitionend', slidIn );
			}
		} );
	}

	// Once Now Playing has slid over the page, the page is neither styled nor painted. Each element
	// keeps its height, so the page's scroll position holds, and it is all back before Now Playing
	// slides away and focus returns to it.
	function slidIn( event ) {
		if ( event.target === np ) {
			np.removeEventListener( 'transitionend', slidIn );
			hidePage();
		}
	}

	function hidePage() {
		if ( np.hidden || ! np.classList.contains( 'is-in' ) ) {
			return;
		}
		const nodes = [ ...document.querySelectorAll( 'body > [data-riff-inert]' ) ];
		const heights = nodes.map( ( node ) => {
			const s = getComputedStyle( node );
			return (
				node.getBoundingClientRect().height -
				parseFloat( s.paddingTop ) -
				parseFloat( s.paddingBottom ) -
				parseFloat( s.borderTopWidth ) -
				parseFloat( s.borderBottomWidth )
			);
		} );
		nodes.forEach( ( node, i ) => {
			node.style.containIntrinsicHeight = `${ Math.max( 0, heights[ i ] ) }px`;
			node.dataset.riffCovered = '';
		} );
	}

	function showPage() {
		for ( const node of document.querySelectorAll( '[data-riff-covered]' ) ) {
			node.removeAttribute( 'data-riff-covered' );
			node.style.removeProperty( 'contain-intrinsic-height' );
		}
	}

	// Whether it covers the bar, as riff.css lays it out (--riff-np-covers), so the shapes are
	// written down once; asked again as the screen changes shape while it is open.
	function coverPage() {
		for ( const node of document.querySelectorAll( '[data-riff-inert]' ) ) {
			node.inert = false;
			node.removeAttribute( 'data-riff-inert' );
		}
		const wide =
			getComputedStyle( np ).getPropertyValue( '--riff-np-covers' ).trim() === '0';
		const covered = wide ? [] : [ $( '.riff-bar' ), $( '.riff-toast' ) ];
		// Modal only where it covers the bar: a screen reader keeps to a modal dialog, and on a wide
		// screen the bar beside it is still how the music is controlled.
		np.setAttribute( 'aria-modal', String( ! wide ) );
		for ( const node of [ ...document.body.children, ...covered ] ) {
			// The track menu is left alone, as the panels leave it: opened from the page before
			// anything played, it sits in the body, and it moves into Up next or Now Playing when
			// opened there, taking an inert set here with it.
			if (
				node &&
				node !== root &&
				! node.classList.contains( 'riff-menu' ) &&
				! node.id.startsWith( 'a11y-speak' ) &&
				! node.inert
			) {
				node.inert = true;
				node.dataset.riffInert = '';
			}
		}
	}
	window.addEventListener( 'resize', () => {
		if ( root.classList.contains( 'is-open' ) && ! P.panelOpen ) {
			coverPage();
		}
	} );

	// ---- The deck on its own. Where the album is the turntable (riff.css, --riff-deck-alone),
	// nothing of the rest of the player is on the screen with it: the bar is gone, on a wide
	// screen too, where Now Playing then covers it as a phone's does, and a panel open beside
	// the page is put away, the listener's choice of it kept, and is back once the deck is left.
	// Asked again whenever what decides it changes: Now Playing opening or closing, the view, a
	// song's video, and the stage's shape (the observer, below).
	let alone = false;
	function immerse() {
		const now =
			root.classList.contains( 'is-open' ) &&
			getComputedStyle( np ).getPropertyValue( '--riff-deck-alone' ).trim() === '1';
		if ( now === alone ) {
			return;
		}
		alone = now;
		if ( alone ) {
			P.hidePanel?.( { quiet: true } );
		}
		// The bar is covered or not before a panel comes back beside a song's video.
		if ( root.classList.contains( 'is-open' ) ) {
			coverPage();
		}
		if ( ! alone ) {
			P.reopenPanel?.();
		}
		P.wakeControls?.();
	}
	new MutationObserver( immerse ).observe( root, {
		attributeFilter: [ 'class', 'data-riff-turntable', 'data-riff-showing', 'data-mode' ],
	} );

	// The desk round the deck is a way out: a press on it, anywhere but the deck and what lies on
	// it, closes Now Playing, as a press beside a dialog does. The plinth's outline is its own
	// box and how far its board reaches past it (riff.css, --riff-plinth-edge); with the record
	// in its sleeve only the sleeve lies on the desk. Where the whole screen is the turntable
	// there is no desk to press. The press starts and ends on the desk, in one place: the arm
	// carried to its next click, and a drag off the record, are not presses of it.
	function onDeck( sx, sy ) {
		const plinth = $( '.riff-plinth' );
		const [ x, y ] = P.flat ? P.flat( sx, sy ) : [ sx, sy ];
		if ( ! plinth || shapedAsDeck() ) {
			return true;
		}
		if ( root.dataset.riffDeck !== 'out' && ! ( 'riffArriving' in root.dataset ) ) {
			return false;
		}
		const box = plinth.getBoundingClientRect();
		const [ top, right, bottom, left ] = getComputedStyle( plinth )
			.getPropertyValue( '--riff-plinth-edge' )
			.trim()
			.split( /\s+/ )
			.map( ( share ) => parseFloat( share ) / 100 || 0 );
		return (
			x > box.left + left * box.width &&
			x < box.right - right * box.width &&
			y > box.top + top * box.height &&
			y < box.bottom - bottom * box.height
		);
	}
	const onDesk = ( e ) =>
		alone &&
		e.button === 0 &&
		! e.target.closest(
			'button, a, input, [role="slider"], .riff-cover, .riff-turntable-extras'
		) &&
		! onDeck( e.clientX, e.clientY );
	let pressedDesk = null;
	np.addEventListener( 'pointerdown', ( e ) => {
		pressedDesk = onDesk( e ) ? { x: e.clientX, y: e.clientY } : null;
	} );
	np.addEventListener( 'click', ( e ) => {
		const from = pressedDesk;
		pressedDesk = null;
		if ( from && onDesk( e ) && Math.hypot( e.clientX - from.x, e.clientY - from.y ) <= 10 ) {
			close();
		}
	} );

	// Now Playing sliding away: what hides it once it has, which opening it again cancels.
	const closing = { done: null, timer: 0 };
	function close( { fromHistory = false } = {} ) {
		// Closed, or already sliding away (the back button's popstate after a close of its own).
		if ( np.hidden || ! root.classList.contains( 'is-open' ) ) {
			return;
		}
		clearTimeout( closing.timer );
		np.removeEventListener( 'transitionend', closing.done );
		np.removeEventListener( 'transitionend', slidIn );
		showPage();
		np.classList.remove( 'is-in' );
		np.style.removeProperty( 'transform' );
		root.classList.remove( 'is-open' );
		reach( false );
		for ( const node of document.querySelectorAll( '[data-riff-inert]' ) ) {
			node.inert = false;
			node.removeAttribute( 'data-riff-inert' );
		}
		P.viewOpened?.( P.showing, false );
		immerse();
		// Hidden once it has slid away, unless it was opened again first.
		const done = () => {
			clearTimeout( closing.timer );
			np.removeEventListener( 'transitionend', closing.done );
			closing.done = null;
			if ( ! root.classList.contains( 'is-open' ) ) {
				np.hidden = true;
				P.syncWakeLock?.();
			}
		};
		if ( P.reduce() ) {
			done();
		} else {
			closing.done = done;
			np.addEventListener( 'transitionend', done, { once: true } );
			closing.timer = setTimeout( done, 400 );
		}
		if ( ! fromHistory && history.state?.riff === 'open' ) {
			history.back();
		}
		// The button that opened it, or, hidden since (its view had nothing for the next track),
		// the button of the view showing.
		const back = [ opener, $( `[data-riff-control="${ P.showing }"]` ) ].find(
			( node ) => node && document.contains( node ) && ! node.hidden
		);
		back?.focus( { preventScroll: true } );
		P.drawControls?.();
		P.wakeControls?.();
	}

	window.addEventListener( 'popstate', () => {
		if ( ! np.hidden && history.state?.riff !== 'open' ) {
			close( { fromHistory: true } );
		}
	} );

	// ---- The background's colour, from the artwork, and the record's label printed on paper of
	// the cover's own colour, its average: dark words on a light colour, light on a dark one, so
	// they read on either. Only for the artwork still showing once it has been read.
	const LABEL = {
		'--riff-label-ink': [ '#141414', '#fff' ],
	};
	// ---- The accent the cover gives (helpers.js coverAccent()), on the player's root and, in the
	// Listen app's own document, on its body for the app: the seek bar, the playing bars, the
	// current Up next item and the wash behind Now Playing take it from --riff-cover-accent
	// (riff.css). Without one, a grey or black cover's or none at all, or with the
	// riff_cover_accent filter off, the player's is the site's --riff-accent and the app's that
	// same colour as the player has it. Colours change at once; the wash, the one large field of
	// it, fades from the last track's to this one's through its opacity (riff.css).
	const standalone = document.body.classList.contains( 'riff-standalone' ) ? document.body : null;
	const wash = $( '.riff-np-bg' );
	// A colour as the page computes it, here in the player, as sRGB red, green, blue and alpha:
	// drawn on a pixel and read back, so a colour in any space a site writes reads the same.
	const pixel = document.createElement( 'canvas' ).getContext( '2d', { willReadFrequently: true } );
	const rgbOf = ( css ) => {
		const probe = document.createElement( 'i' );
		probe.style.color = css;
		root.append( probe );
		const computed = getComputedStyle( probe ).color;
		probe.remove();
		if ( ! pixel ) {
			return [ 0, 0, 0, 1 ];
		}
		pixel.clearRect( 0, 0, 1, 1 );
		pixel.fillStyle = computed;
		pixel.fillRect( 0, 0, 1, 1 );
		const [ r, g, b, a ] = pixel.getImageData( 0, 0, 1, 1 ).data;
		return [ r, g, b, a / 255 ];
	};
	// A colour with see-through parts laid on an opaque one.
	const layered = ( [ r, g, b, a ], under ) => [ r, g, b ].map( ( v, i ) => v * a + under[ i ] * ( 1 - a ) );
	const css = ( [ r, g, b ] ) => `rgb(${ Math.round( r ) } ${ Math.round( g ) } ${ Math.round( b ) })`;
	let painted = '';
	function setAccent( value ) {
		const was = painted;
		painted = value;
		if ( value ) {
			root.style.setProperty( '--riff-cover-accent', value );
		} else {
			root.style.removeProperty( '--riff-cover-accent' );
		}
		standalone?.style.setProperty( '--riff-cover-accent', value || css( rgbOf( 'var(--riff-accent)' ) ) );
		if ( wash && was !== value ) {
			wash.style.setProperty( '--riff-cover-accent-was', was || 'var(--riff-accent)' );
			// The fade starts over for each track.
			wash.removeAttribute( 'data-riff-fading' );
			void wash.offsetWidth;
			wash.setAttribute( 'data-riff-fading', '' );
		}
	}
	function accent( c, tinted ) {
		if ( P.data.coverAccent === false ) {
			if ( standalone && ! standalone.style.getPropertyValue( '--riff-cover-accent' ) ) {
				setAccent( '' );
			}
			return;
		}
		if ( ! c ) {
			setAccent( '' );
			return;
		}
		const surface = rgbOf( 'var(--riff-surface)' );
		const backgrounds = [
			surface,
			rgbOf( 'var(--riff-bg)' ),
			rgbOf( tinted ),
			// A row under the pointer in Up next, its wash over the sheet.
			layered( rgbOf( 'var(--riff-hover)' ), surface ),
		];
		if ( standalone ) {
			backgrounds.push( rgbOf( 'var(--riff-standalone-bg, #030303)' ) );
		}
		const colour = coverAccent( c, backgrounds.map( ( bg ) => bg.slice( 0, 3 ) ) );
		setAccent( colour ? css( colour ) : '' );
	}

	function tint( src ) {
		const clear = () => {
			for ( const name of [ '--riff-tint', '--riff-label-paper', ...Object.keys( LABEL ) ] ) {
				root.style.removeProperty( name );
			}
			accent( null );
		};
		if ( ! src ) {
			clear();
			return;
		}
		average( src ).then( ( c ) => {
			if ( largest( P.track()?.art ) !== src && P.track()?.video?.poster !== src ) {
				return;
			}
			if ( ! c ) {
				clear();
				return;
			}
			const [ h, sat ] = hsl( c.r, c.g, c.b );
			const tinted = `hsl(${ Math.round( h ) } ${ Math.round( Math.min( sat, 0.55 ) * 100 ) }% 22%)`;
			root.style.setProperty( '--riff-tint', tinted );
			accent( c, tinted );
			root.style.setProperty(
				'--riff-label-paper',
				`rgb(${ Math.round( c.r ) } ${ Math.round( c.g ) } ${ Math.round( c.b ) })`
			);
			for ( const [ name, [ onLight, onDark ] ] of Object.entries( LABEL ) ) {
				root.style.setProperty( name, c.light ? onLight : onDark );
			}
		} );
	}

	// ---- How the album is pressed comes with its track list on the library route, asked for once an
	// album and kept (Library::pressing()), so the sleeve Riff draws and the record are one pressing.
	// Until the track list arrives the record has plain grooves.

	// ---- The record's grooves: between the lead-out and the lead-in at 97% of its radius, a band
	// for each of the side's tracks, wider as the track is longer, since a record's grooves keep one
	// pitch and one speed, so its playing time runs evenly across the radius. A glossy ring parts
	// each band from the next, as on a pressed record. Drawn once a side, as a background; the
	// label says the side and the speed.
	const LEAD_IN = 0.97;
	const leadOut = () => ( root.dataset.riffFormat === '7' ? 0.56 : 0.4 );
	const albums = new Map();
	let playing = null;
	// The deck's speed, as chosen on its keys (null: the record's own), and its pitch, in percent.
	let chosen = null;
	let pitch = 0;
	let side = null;
	function groove( t ) {
		const album = t?.post?.id || null;
		if ( album !== playing ) {
			stopRunout();
			if ( playing !== null ) {
				change();
			}
			playing = album;
			side = null;
			// A new record plays at its own speed; the pitch stays where the hand left it.
			chosen = null;
		}
		place( t );
		if ( albums.has( album ) || ! album || ! P.data.library || navigator.connection?.saveData ) {
			return;
		}
		albums.set( album, null );
		const url = route( P.data.library, String( album ) );
		url.searchParams.set( '_fields', 'tracks,pressing' );
		P.internal
			.request( url )
			.then( ( r ) => ( r.ok ? r.json() : null ) )
			.then( ( post ) => {
				const tracks = post?.tracks || [];
				const lengths = tracks.map( ( q ) => Number( q.duration ) || 0 );
				let length = 0;
				const starts = lengths.map( ( l ) => ( length += l ) - l );
				if ( ! length ) {
					albums.delete( album );
					return;
				}
				albums.set( album, {
					ids: tracks.map( ( q ) => String( q.id ) ),
					titles: tracks.map( ( q ) => q.title || '' ),
					lengths,
					starts,
					length,
					levels: tracks.map( ( q ) => ( typeof q.levels === 'string' ? q.levels : '' ) ),
					format: post.pressing?.format || '12',
					sides: post.pressing?.sides || [],
				} );
				if ( playing === album ) {
					place( P.track() );
				}
			} )
			.catch( () => albums.delete( album ) );
	}

	// The side the track is on, and the record it is on: a new side of the same record turns the
	// record over, another record of the set comes out of the sleeve in its place.
	function sideOf( t ) {
		const album = albums.get( playing );
		const at = album && t ? album.ids.indexOf( String( t.id ) ) : -1;
		return at < 0 ? null : album.sides.find( ( s ) => at >= s.from && at < s.to ) || null;
	}
	function place( t ) {
		const album = albums.get( playing );
		const next = sideOf( t );
		// Moved on while the stylus rides the run-out: the side still up is the one it was in.
		if ( runout.until ) {
			side = runout.from;
			stopRunout();
		}
		const show = () => {
			root.dataset.riffFormat = album?.format || '12';
			spins.forEach( ( a ) => a.effect.updateTiming( { duration: turnsIn() } ) );
			strobe();
			cut( next );
			label( next );
			needle();
			bands();
		};
		if ( ! side || ! next || next === side ) {
			side = next;
			show();
			return;
		}
		const sameRecord = side.record === next.record;
		const was = side;
		side = next;
		const over = () => {
			if ( sameRecord ) {
				flip( show );
			} else {
				change();
				show();
			}
		};
		// Played to its end, the side leaves the stylus in its run-out first.
		if ( performance.now() - ended < 1500 && seen() && 'riffDown' in ( $( '.riff-arm' )?.dataset || {} ) ) {
			ended = 0;
			runout.from = was;
			runout( over );
		} else {
			over();
		}
	}
	// The label says the side and the speed, and lists the side's tracks as a pressed label does:
	// A1, A2 and on, each with its time.
	function label( on ) {
		const small = $( '.riff-label small' );
		if ( small ) {
			const speed = root.dataset.riffFormat === '7' ? '45' : '33⅓';
			small.textContent = on ? `${ on.name } · ${ speed }` : speed;
		}
		// And the side's matrix number in the run-out, as a pressing plant scratches it.
		const etch = $( '[data-riff-etch]' );
		if ( etch ) {
			etch.textContent = on ? `RIFF-${ playing }-${ on.name }1` : '';
		}
		const list = $( '.riff-label-tracks' );
		const album = albums.get( playing );
		if ( ! list ) {
			return;
		}
		list.replaceChildren(
			...( on && album ? album.titles.slice( on.from, on.to ) : [] ).map( ( title, k ) => {
				const li = document.createElement( 'li' );
				li.textContent = `${ on.name }${ k + 1 }  ${ title }  ${ time( album.lengths[ on.from + k ] ) }`;
				return li;
			} )
		);
	}

	// ---- The run-out. A side played to its end leaves the stylus to the lead-out groove, which
	// carries it in across the dead wax in half a turn to the locked groove, a closed ring it rides
	// until the arm is lifted. The ring's join clicks once a turn, the same click each time, since
	// it is the same groove: 1.8 s apart at 33⅓. Two turns of it, and then the arm goes back and the
	// record is turned over or changed. Only where the record is seen, and only where the music
	// passes through Web Audio (meter.js), as the click is played there; elsewhere the arm still
	// rides the run-out, in silence. The platter turns on at the music's last speed meanwhile, the
	// music over, and is braked once the arm is lifted.
	const LOCKED = 1.06;
	// Never, until a track ends: the page's clock starts at its load, not at nothing.
	let ended = -Infinity;
	// Noted before media.js loads the next track on the same event: a capturing listener on the
	// element itself is called before the others there.
	for ( const el of [ P.audio, P.video ] ) {
		el.addEventListener( 'ended', () => ( ended = performance.now() ), true );
	}
	function runout( then ) {
		const arm = $( '.riff-arm' );
		const m = P.el();
		const rate = m.playbackRate || 1;
		const once = 60000 / ( ( root.dataset.riffFormat === '7' ? 45 : 100 / 3 ) * rate );
		const id = ++runout.id;
		runout.until = performance.now() + once * 2.5;
		coast( rate, rate );
		sweep?.pause();
		runout.anim = arm.animate(
			[ { rotate: `${ angle( 1 ).toFixed( 2 ) }deg` }, { rotate: `${ angle( LOCKED ).toFixed( 2 ) }deg` } ],
			{ duration: once / 2, easing: 'ease-in', fill: 'forwards' }
		);
		// Woken once the ended event is through: meter.js suspends the context on it, after this.
		const ctx = P.analyser?.context;
		setTimeout( () =>
			ctx?.resume()
				.then( () => {
					if ( id === runout.id ) {
						click( ctx, once / 2 - 50 );
						click( ctx, once * 1.5 - 50 );
					}
				} )
				.catch( () => {} )
		);
		runout.done = setTimeout( () => {
			if ( id !== runout.id ) {
				return;
			}
			runout.until = 0;
			if ( ctx && P.el().paused ) {
				ctx.suspend().catch( () => {} );
			}
			windDown();
			then();
		}, once * 2.5 );
	}
	runout.id = 0;
	runout.until = 0;
	// A side changed some other way while the stylus rides the run-out: it is lifted from there.
	function stopRunout() {
		if ( ! runout.until ) {
			return;
		}
		runout.id++;
		runout.until = 0;
		clearTimeout( runout.done );
		runout.anim?.cancel();
		runout.anim = null;
		// The platter, turning on for the run-out, is braked; music that starts takes it first.
		windDown();
	}
	// The click: the groove's join under the stylus, a tick of a millisecond and a half over a
	// low thump of the cartridge, soft. Drawn once, from a fixed sequence, so every turn is the
	// same click, as every turn is the same groove.
	function click( ctx, after ) {
		if ( ! click.sound || click.sound.sampleRate !== ctx.sampleRate ) {
			const rate = ctx.sampleRate;
			const sound = ctx.createBuffer( 1, Math.round( rate * 0.03 ), rate );
			const data = sound.getChannelData( 0 );
			let seed = 7;
			for ( let n = 0; n < data.length; n++ ) {
				seed = ( seed * 1103515245 + 12345 ) % 2147483648;
				const s = n / rate;
				data[ n ] =
					( ( seed / 1073741824 - 1 ) * Math.exp( -s / 0.0015 ) ) / 2 +
					Math.sin( 2 * Math.PI * 70 * s ) * Math.exp( -s / 0.006 );
			}
			click.sound = sound;
		}
		const source = ctx.createBufferSource();
		const gain = ctx.createGain();
		source.buffer = click.sound;
		gain.gain.value = 0.12;
		source.connect( gain ).connect( ctx.destination );
		source.start( ctx.currentTime + after / 1000 );
	}

	// ---- What a hand moves (the record out of its sleeve and turned over, the sleeve set down,
	// the arm carried), it moves as a hand does: on the minimum-jerk path, x = 10τ³ − 15τ⁴ + 6τ⁵
	// for τ from 0 to 1 (Flash and Hogan, 1985), which reaching movements follow, setting off and
	// arriving with neither speed nor acceleration. As an easing, the whole of it or the part from
	// a to b, drawn with linear() where a browser has it; elsewhere the nearest curve. riff.css has
	// the whole of it as --riff-hand.
	const jerk = ( t ) => t * t * t * ( 10 - 15 * t + 6 * t * t );
	const linear = !! window.CSS?.supports?.( 'animation-timing-function', 'linear(0, 1)' );
	function hand( a = 0, b = 1 ) {
		if ( ! linear && a === 0 && b === 1 ) {
			return 'cubic-bezier(0.5, 0, 0.5, 1)';
		}
		if ( ! linear ) {
			return a === 0 ? 'ease-in' : 'ease-out';
		}
		const points = [];
		for ( let i = 0; i <= 20; i++ ) {
			points.push( ( ( jerk( a + ( ( b - a ) * i ) / 20 ) - jerk( a ) ) / ( jerk( b ) - jerk( a ) ) ).toFixed( 3 ) );
		}
		return `linear(${ points.join( ', ' ) })`;
	}

	// ---- The record set down on the platter: carried there from the sleeve a few millimetres
	// above the mat, and let go, it falls those last millimetres under gravity, h = ½gt², so in
	// t = √(2h/g), 29 ms from 4 mm, and lands with a bounce or two, each keeping a share of the
	// speed it landed with, until it lies still. Seen from above, its height is its size: a thing h
	// nearer the eye than the mat, from D away, looks D / (D − h) as large.
	const FALL = 4;
	const EYE = 500;
	const G = 9.81e-3;
	const KEEP = 0.3;
	// Falling from rest, the distance grows as t²; rising to a stop, as 1 − (1 − t)². Each is a
	// cubic Bézier exactly.
	const FALLING = 'cubic-bezier(0.3333, 0, 0.6667, 0.3333)';
	const RISING = 'cubic-bezier(0.3333, 0.6667, 0.6667, 1)';
	function lay() {
		const record = $( '.riff-record' );
		const carry = record ? parseFloat( getComputedStyle( record ).transitionDuration ) * 1000 : 0;
		if ( ! carry || ! seen() ) {
			return;
		}
		const up = ( h ) => ( { transform: `scale(${ ( EYE / ( EYE - h ) ).toFixed( 5 ) })` } );
		const frames = [
			{ ...up( 0 ), at: 0, easing: hand() },
			{ ...up( FALL ), at: carry, easing: FALLING },
		];
		let t = carry + Math.sqrt( ( 2 * FALL ) / G );
		frames.push( { ...up( 0 ), at: t } );
		for ( let h = FALL * KEEP * KEEP; h > 0.05; h *= KEEP * KEEP ) {
			const rise = Math.sqrt( ( 2 * h ) / G );
			frames[ frames.length - 1 ].easing = RISING;
			frames.push( { ...up( h ), at: t + rise, easing: FALLING } );
			t += 2 * rise;
			frames.push( { ...up( 0 ), at: t } );
		}
		record.animate(
			frames.map( ( { at, ...frame } ) => ( { ...frame, offset: at / t } ) ),
			{ duration: t }
		);
	}

	// ---- A new side of the same record, as a hand turns it over. The cue lever lifts the arm and
	// the hand takes it back to its rest, clear of the record; only then is the record lifted
	// quickly off the spindle, turned over about its diameter, unhurried, the other side's label
	// coming up as it passes edge-on, and set down gently. Once it lies flat the motor starts and
	// the hand carries the arm over to the new side's lead-in, where it is lowered. The music waits
	// for it (turn()): FLIP after the run-out, as long as it has always waited, and the platter's
	// pull up to a crawl after that. The page's record keeps its box; deck-gl.js draws the lift and
	// the turn from --riff-lift and --riff-turn (riff.css), raising it as it turns so its edge
	// clears the mat.
	const FLIP = 1450;
	const OVER = { lift: 100, turn: 420, down: 130, whole: 600 };
	function flip( show ) {
		const record = $( '.riff-record' );
		const arm = $( '.riff-arm' );
		if ( ! seen() || ! record ) {
			show();
			return;
		}
		// Taken to its rest from wherever it is seen, whatever was moving it: the music's sweep, a
		// carry or the spring of its own turn (riff.css).
		const tube = arm?.querySelector( '.riff-arm-tube' );
		const at = arm ? shown( arm ) + ( parseFloat( tube ? getComputedStyle( tube ).rotate : '' ) || 0 ) : REST;
		delete arm?.dataset.riffDown;
		lift();
		if ( arm ) {
			swing.anim?.cancel();
			arm.getAnimations().forEach( ( a ) => a.transitionProperty && a.cancel() );
			swing( arm, at, REST, brisk );
		}
		const now = performance.now();
		flip.until = now + FLIP;
		const { lift: up, turn: over, down, whole } = OVER;
		// The arm on its rest first, and the record set down before the motor starts.
		const delay = Math.min( FLIP - whole, Math.max( 0, ( swing.until || 0 ) - now ) + 40 );
		const set = record.animate(
			[
				{ '--riff-lift': 0, offset: 0, easing: 'ease-out' },
				{ '--riff-lift': 1, offset: up / whole },
				{ '--riff-lift': 1, offset: 1 - down / whole, easing: hand() },
				{ '--riff-lift': 0, offset: 1 },
			],
			{ duration: whole, delay }
		);
		const half = { duration: over / 2 };
		record
			.animate( [ { '--riff-turn': '0deg' }, { '--riff-turn': '90deg' } ], { ...half, delay: delay + ( whole - over ) / 2, easing: hand( 0, 0.5 ) } )
			.finished.then( () => {
				show();
				return record.animate( [ { '--riff-turn': '90deg' }, { '--riff-turn': '180deg' } ], { ...half, easing: hand( 0.5, 1 ) } ).finished;
			} )
			// And the arm carried back over the record once it lies on the mat again, on the lever,
			// to be lowered there (lowerOver()).
			.then( () => set.finished )
			.then( () => {
				if ( ! arm || root.dataset.riffDeck !== 'out' ) {
					return;
				}
				arm.dataset.riffDown = '';
				arm.dataset.riffUp = '';
				needle( false, careful );
				lowerOver( arm );
			} )
			.catch( () => {} );
	}

	// ---- A new album, or the next record of a set: the needle goes back to its rest, the record
	// back into its sleeve, the two leave, and the new sleeve comes in with its record inside, which
	// then slides out onto the platter. The turntable stays where it is. What leaves is a copy of the old cover
	// and record, made before the new artwork is painted, so it is the old album that leaves. All of
	// it moves by transform and opacity, on the compositor, and only where it is seen.
	function change() {
		const stage = $( '.riff-stage' );
		if ( np.hidden || P.reduce() || P.isVideo() || ! stage || ! roomy() ) {
			return;
		}
		const leaving = document.createElement( 'div' );
		leaving.className = 'riff-leaving';
		leaving.setAttribute( 'aria-hidden', 'true' );
		for ( const el of [ $( '.riff-record' ), $( '.riff-cover' ) ] ) {
			const copy = el.cloneNode( true );
			for ( const n of [ copy, ...copy.querySelectorAll( '*' ) ] ) {
				n.removeAttribute( 'data-riff-art' );
				n.removeAttribute( 'data-riff-text' );
				n.removeAttribute( 'id' );
			}
			copy.alt = '';
			leaving.append( copy );
		}
		stage.append( leaving );
		// The real record goes back in its sleeve, unseen while the new sleeve comes in.
		deck( false );
		const sleeve = leaving.querySelector( '.riff-record' );
		const out = getComputedStyle( $( '.riff-record' ) ).translate;
		const ease = hand();
		sleeve.animate( [ { translate: out }, { translate: '0 0' } ], { duration: 250, delay: 200, easing: ease, fill: 'both' } );
		leaving
			.animate(
				[ { transform: 'none', opacity: 1 }, { transform: 'translateX(-40%)', opacity: 0 } ],
				{ duration: 300, delay: 400, easing: ease, fill: 'forwards' }
			)
			.finished.then( () => leaving.remove() );
		root.dataset.riffArriving = '';
		clearTimeout( change.done );
		change.until = performance.now() + ARRIVE;
		change.done = setTimeout( () => {
			delete root.dataset.riffArriving;
			// The new record comes out, for the music waiting on it or already playing.
			if ( ! P.el().paused || 'riffCued' in root.dataset ) {
				deck( true );
			}
		}, ARRIVE );
	}

	// ---- The strobe on the platter's rim, as the deck's lamp shows it (riff.css): between two of
	// its flashes the platter turns some way, and a row of dots seems to move by only what is left
	// over after the whole dots, so each row turns by that alone, a turn a second for each 360° a
	// second it seems to drift. Still while the platter is.
	const FLASHES = 120;
	function strobe() {
		const m = P.el();
		const turning = ( 'riffTurning' in root.dataset || coasting !== null ) && root.dataset.riffDeck === 'out' && ! P.reduce();
		const rpm = root.dataset.riffFormat === '7' ? 45 : 100 / 3;
		const step = turning ? ( ( rpm / 60 ) * 360 * ( coasting ?? ( m.playbackRate || 1 ) ) ) / FLASHES : 0;
		// The rows' dots, round, at their radii on the rim, the platter's radius 100: drawn once, the
		// two together where the room lights them, and each on its own in the lamp's patch.
		const ROWS = [ [ 216, 95.7 ], [ 160, 97.9 ] ];
		const dots = ( rows ) => {
			let circles = '';
			for ( const [ count, radius ] of rows ) {
				for ( let n = 0; n < count; n++ ) {
					const a = ( n * 2 * Math.PI ) / count;
					circles += `<circle cx="${ ( radius * Math.cos( a ) ).toFixed( 2 ) }" cy="${ ( radius * Math.sin( a ) ).toFixed( 2 ) }" r="0.62"/>`;
				}
			}
			return `<svg viewBox="-100 -100 200 200" focusable="false">${ circles }</svg>`;
		};
		const room = $( '.riff-strobe-room i' );
		if ( room && ! room.firstChild ) {
			room.innerHTML = dots( ROWS );
		}
		$$( '.riff-strobe-lamp i' ).forEach( ( row, k ) => {
			if ( ! row.firstChild ) {
				row.innerHTML = dots( [ ROWS[ k ] ] );
			}
			const dot = 360 / ROWS[ k ][ 0 ];
			const seen = step - dot * Math.round( step / dot );
			if ( ! row.drift ) {
				row.drift = row.animate( [ { rotate: '0deg' }, { rotate: '360deg' } ], { duration: 1000, iterations: Infinity } );
				// Far into its turns, so it can run backwards as long as it needs to: run back from its
				// start, an animation stops there.
				row.drift.currentTime = 1e9;
			}
			row.drift.updatePlaybackRate( ( seen * FLASHES ) / 360 );
		} );
	}

	// The album is the cover on its own where Now Playing is portrait, as on a phone held upright,
	// and the turntable where it is landscape, as on a phone on its side or a computer's window.
	// riff.css's container query on Now Playing says which (--riff-deck), so the two never
	// disagree; while Now Playing is closed it has no size, so the last answer holds, and before it
	// has ever opened the window's shape stands in, so music playing on a computer already has its
	// record out when Now Playing first opens. Turning the phone, unfolding it or resizing the
	// window brings the record out or puts it back. A site that turned the turntable off (Settings ›
	// Media), a listener who asks for less motion, and a browser that can't draw the deck (no
	// WebGL2, a card too slow for it, a context lost, forced colours: deck-gl.js says so through
	// P.drawable) have the cover in every shape. The page's own deck is never painted: it is the
	// drawn deck's control layer.
	let drawable = typeof window.WebGL2RenderingContext !== 'undefined';
	const forcedColours = window.matchMedia?.( '(forced-colors: active)' );
	const turntable = () =>
		P.showing === 'album' && P.data.turntable !== false && ! P.reduce() && drawable && ! forcedColours?.matches;
	function roomy() {
		if ( ! turntable() ) {
			return false;
		}
		const cover = $( '.riff-cover' );
		if ( ! np.hidden && cover ) {
			roomy.last = getComputedStyle( cover ).getPropertyValue( '--riff-deck' ).trim() === '1';
		}
		return roomy.last ?? window.innerWidth > window.innerHeight;
	}
	// Where the turntable shows, the record comes out whether or not it is playing, as setting a
	// record on the platter does. Where the whole screen is the turntable (riff.css: an unfolded
	// phone, a phone on its side), the deck has its own controls too.
	const OPENING = 400;
	const wholeDeck = turntable;
	const shapedAsDeck = () =>
		!! $( '.riff-cover' ) &&
		getComputedStyle( $( '.riff-cover' ) ).getPropertyValue( '--riff-deck-screen' ).trim() === '1';
	// For the stylesheet: off, the cover on its own, with no record or deck.
	function markRoom() {
		if ( roomy() ) {
			delete root.dataset.riffTurntable;
			// The deck drawn in WebGL, where the browser has it, from the first time it shows: once
			// Now Playing has finished opening, if the music didn't have it ready before then.
			P.feature( 'deck-gl', { quiet: true } );
			// And the music's level in the bar, where the deck's keys take the transport's place.
			P.feature( 'level' );
		} else {
			root.dataset.riffTurntable = 'off';
		}
	}
	// Music playing in a window wider than tall has its record out when Now Playing opens (roomy()),
	// so the WebGL deck is made ready while it plays, not in the frames of Now Playing opening.
	const warm = () => {
		if ( turntable() && window.innerWidth > window.innerHeight ) {
			P.feature( 'deck-gl', { quiet: true } );
		}
	};
	if ( $( '.riff-stage' ) ) {
		P.audio?.addEventListener( 'playing', warm, { once: true } );
	}
	if ( $( '.riff-stage' ) && 'ResizeObserver' in window ) {
		const reroom = () => {
			// What the stylesheet was told, against what the shape and the listener ask for now.
			const was = ! ( 'riffTurntable' in root.dataset );
			const now = roomy();
			if ( np.hidden || now === was ) {
				return;
			}
			markRoom();
			clearTimeout( deck.opening );
			// Onto the deck its speed and pitch hold; off it the music is at its own speed again.
			retune( false );
			if ( now && ! P.el().paused && ! held() ) {
				deck( true );
				return;
			}
			if ( now ) {
				// Opened: the sleeve settles at the deck's edge first, then the record slides out of it.
				deck.opening = setTimeout( () => deck( roomy() ), OPENING );
				return;
			}
			deck( false );
		};
		new ResizeObserver( reroom ).observe( $( '.riff-stage' ) );
		// Asking for less motion puts the record away; asking for it again brings it out. So do
		// forced colours, and the drawn deck going or coming back (deck-gl.js).
		window.matchMedia( '(prefers-reduced-motion: reduce)' ).addEventListener?.( 'change', reroom );
		forcedColours?.addEventListener?.( 'change', reroom );
		P.drawable = ( yes ) => {
			if ( drawable !== yes ) {
				drawable = yes;
				reroom();
			}
		};
	}

	// The record out of its sleeve or back in it; out, the needle drops once it has come clear.
	function deck( out ) {
		const arm = $( '.riff-arm' );
		if ( ! out || ! roomy() ) {
			rested = false;
			needle.place = false;
			clearTimeout( deck.drop );
			clearTimeout( lowerOver.wait );
			stopRunout();
			delete root.dataset.riffDeck;
			delete arm?.dataset.riffDown;
			lift();
			strobe();
			stand( false );
			return;
		}
		// Already out, the needle is down or on its way: asked again before it lands (opening the
		// view as the music starts asks twice), the drop under way is the one that lands it.
		if ( root.dataset.riffDeck === 'out' ) {
			return;
		}
		// Shown while the music plays (Now Playing opened, the phone turned, the window widened), the
		// record is already on the platter at the music's speed and the stylus in the groove the music
		// is at, rather than set down and dropped onto under music already heard.
		if ( ! P.el().paused && ! held() && arm ) {
			root.dataset.riffAt = '';
			root.dataset.riffDeck = 'out';
			stand( true );
			arm.dataset.riffDown = '';
			// A carry back to the rest still under way, from the deck going away, is over.
			arm.querySelector( '.riff-arm-tube' )?.getAnimations().forEach( ( a ) => a.cancel() );
			// Placed there, not carried: as soon as the side's length is known, if it isn't yet.
			needle.place = true;
			needle( true );
			platter( P.el().playbackRate || 1 );
			requestAnimationFrame( () => requestAnimationFrame( () => delete root.dataset.riffAt ) );
			return;
		}
		root.dataset.riffDeck = 'out';
		stand( true );
		lay();
		needle();
		strobe();
		// The needle onto the record as a hand does it: lifted, carried over its groove, and lowered
		// by the cue lever once it is there; the music waits for it (turn()).
		deck.drop = setTimeout( () => {
			if ( arm ) {
				arm.dataset.riffDown = '';
				arm.dataset.riffUp = '';
				needle();
				lowerOver( arm );
			}
		}, P.reduce() ? 0 : DROP );
	}

	// ---- Starting and stopping, as a turntable does where the record is seen: Now Playing open on
	// a song, with motion. To start, the record comes out of its sleeve if it is in it (after a new
	// album has come in), the platter starts, the needle drops (drop()), and the music starts as it
	// lands: the platter's speed is the music's, the pitch rising with it as a record's does, the
	// platter's turn and the arm's sweep following the same rate. To stop, it winds down, the pitch
	// falling, and then stops. Moving on to the next track, it keeps turning. Where the record is
	// not seen, the music starts and stops at once. The browser's own speed change does the bending
	// (preservesPitch off), on the element's own clock.
	//
	// The platter moves as a direct-drive deck's does. Its motor pulls with a constant torque, so
	// its speed rises at a constant rate, in a straight line: from rest to 33⅓ in 0.7 s. It brakes
	// with the same torque, from 33⅓ to rest in 0.7 s. A new speed or pitch while it turns is the
	// same pull, for as long as the change takes. The music is heard from a crawl up, as slow as
	// the player lets it go; below that the platter turns with the music silent (coast()).
	const ARRIVE = 850;
	const DROP = 450;
	// The hand's carry of the arm from its rest to the groove (swing()): the music waits until the
	// stylus is in it.
	const LAND = 600;
	const CRAWL = 0.3;
	// In revolutions a minute, each millisecond. The published specification of a direct-drive
	// turntable gives 0.7 s from standstill to 33⅓ (build-up characteristics) on 0.18 N·m of
	// starting torque. Its brake is electronic, the motor itself pulling against the turn, and no
	// stopping time is published, so it is taken at the motor's own torque: 33⅓ to rest in the
	// same 0.7 s.
	const TORQUE = 100 / 3 / 700;
	const BRAKE = TORQUE;
	// How long the platter takes from one rate to another, the rates as shares of the record's own
	// speed.
	const pull = ( from, to ) =>
		( Math.abs( to - from ) * ( root.dataset.riffFormat === '7' ? 45 : 100 / 3 ) ) / ( to > from ? TORQUE : BRAKE );
	// The most of the pull one frame may take (bend()).
	const MOST = 34;
	let ramping = 0;
	let stowing = 0;
	// Whether the track shows as its video is the track's (P.isVideo()), not P.mode: that is the
	// listener's choice for a track that has a video, and is 'video' until they choose the song, so
	// it would say every song in such a session was a picture and start and stop it at once.
	const seen = () =>
		! np.hidden && ! P.away() && ! P.reduce() && ! P.isVideo() && roomy();
	function bend( m, to ) {
		const from = m.playbackRate || 1;
		const ms = pull( from, to );
		const id = ++ramping;
		P.ramping = true;
		m.preservesPitch = m.webkitPreservesPitch = false;
		return new Promise( ( done ) => {
			// The pull goes on by the frames drawn, two frames' worth at most at a time: a frame
			// held up (the page busy) holds the platter back a little, where by the clock the music
			// would leap in pitch.
			let pulled = 0;
			let then = performance.now();
			const step = ( now ) => {
				if ( id !== ramping ) {
					return done( false );
				}
				pulled += Math.min( MOST, Math.max( 0, now - then ) );
				then = now;
				// A page put out of sight stops drawing frames, which would leave the music at whatever
				// speed it had reached: out of sight, the pull is over at once.
				const k = ms && ! document.hidden ? Math.min( 1, pulled / ms ) : 1;
				const rate = k < 1 ? from + ( to - from ) * k : to;
				m.playbackRate = rate;
				// The platter and the arm take the music's new speed in the same frame, not a frame
				// later on its ratechange.
				drive( rate );
				if ( k < 1 ) {
					requestAnimationFrame( step );
					return;
				}
				bend.finish = null;
				P.ramping = false;
				done( true );
			};
			bend.finish = () => step( performance.now() );
			// Out of sight already (play pressed, then the tab left while the arm came down), no
			// frame would come to start it: it is over at once.
			if ( document.hidden ) {
				bend.finish();
			} else {
				requestAnimationFrame( step );
			}
		} );
	}
	document.addEventListener( 'visibilitychange', () => document.hidden && bend.finish?.() );
	// The platter's and the arm's rate, set where the music's is.
	function drive( rate ) {
		if ( coasting === null ) {
			platter( rate );
		}
		if ( sweep ) {
			rated( sweep, rate );
		}
	}
	// An animation's rate, set at once so it changes in the frame the music's does; while its play
	// is still pending, setting it would hold it there, so it waits for that.
	function rated( a, rate ) {
		if ( a.pending ) {
			a.updatePlaybackRate( rate );
		} else if ( a.playbackRate !== rate ) {
			a.playbackRate = rate;
		}
	}
	function settle( m ) {
		ramping++;
		P.ramping = false;
		const to = deckRate();
		m.playbackRate = m.defaultPlaybackRate = to;
		// The deck's speed moves the pitch, as a record's does; the listener's own keeps it.
		m.preservesPitch = m.webkitPreservesPitch = deckOnly() === 1;
	}
	// Whether the music is already as settle() leaves it: at the deck's speed, its pitch kept or
	// not as that speed asks.
	function settled( m ) {
		const only = deckOnly();
		const to = only * P.speed;
		return m.playbackRate === to && m.defaultPlaybackRate === to && ( m.preservesPitch !== false ) === ( only === 1 );
	}
	// The listener's own speed, from window.riff.speed(): set on both elements, so it holds when
	// the song hands over to its video and for every track after. While the platter is being
	// pulled up to speed or wound down, the music settles at the new speed once it gets there.
	function respeed( rate ) {
		P.speed = rate;
		const m = P.el();
		for ( const other of [ P.audio, P.video ] ) {
			if ( other !== m ) {
				other.playbackRate = other.defaultPlaybackRate = deckRate();
				other.preservesPitch = other.webkitPreservesPitch = deckOnly() === 1;
			}
		}
		if ( ! P.ramping ) {
			settle( m );
		}
	}

	// The platter's speed while it turns with the music silent: coming up to a crawl before the
	// music starts, or on down to rest after it has stopped. Its turn and the strobe follow this
	// rate in place of the music's (platter()); null while they follow the music.
	let coasting = null;
	let coasts = 0;
	// The record, its label and its run-out turn as one, by animations the script keeps: speed 0 is
	// a platter at rest, so the record stays at the angle it stopped at, whatever was in view, and
	// outlasts Now Playing closing or the deck going away, which a stylesheet's animation doesn't.
	const turnsIn = () => 60000 / ( root.dataset.riffFormat === '7' ? 45 : 100 / 3 );
	const spins = $$( '.riff-turns' ).map( ( turns ) => {
		const a = turns.animate( [ { rotate: '0deg' }, { rotate: '360deg' } ], { duration: turnsIn(), iterations: Infinity } );
		a.playbackRate = 0;
		return a;
	} );
	let spinRate = 1;
	function platter( rate ) {
		spinRate = rate;
		const on = ( 'riffTurning' in root.dataset || coasting !== null ) && root.dataset.riffDeck === 'out' && ! P.reduce();
		for ( const a of spins ) {
			rated( a, on ? rate : 0 );
		}
		strobe();
	}
	new MutationObserver( () => platter( spinRate ) ).observe( root, {
		attributeFilter: [ 'data-riff-turning', 'data-riff-coasting', 'data-riff-deck' ],
	} );
	function coast( from, to, then ) {
		const id = ++coasts;
		const ms = pull( from, to );
		const t0 = performance.now();
		coasting = from;
		platter( from );
		root.dataset.riffCoasting = '';
		const step = ( now ) => {
			if ( id !== coasts ) {
				return;
			}
			const k = ms ? Math.min( 1, ( now - t0 ) / ms ) : 1;
			coasting = from + ( to - from ) * k;
			platter( coasting );
			if ( k < 1 ) {
				requestAnimationFrame( step );
			} else if ( ! to ) {
				release();
				then?.();
			}
		};
		requestAnimationFrame( step );
	}
	// The music has the platter again, or the platter has come to rest.
	function release() {
		coasts++;
		coasting = null;
		delete root.dataset.riffCoasting;
		platter( P.el().playbackRate || 1 );
	}
	const windDown = () => coasting !== null && coast( coasting, 0 );

	function cued( on ) {
		root.toggleAttribute( 'data-riff-cued', on );
	}
	// The cue lever. Up, the stylus rides above its groove (data-riff-up=""); lowering, it sinks
	// onto it ("lowering"); down, the attribute is gone. It is raised only once the platter is at
	// rest, the music long silent, and the music is heard only once it is down again.
	const tonearmOf = () => $( '.riff-arm' );
	function raise() {
		const arm = tonearmOf();
		if ( arm && 'riffDown' in arm.dataset && P.el().paused && ! held() ) {
			arm.dataset.riffUp = '';
		}
	}
	function lowered() {
		delete tonearmOf()?.dataset.riffUp;
	}
	// ---- The cue: where starting and stopping has got to, one sequence the deck's parts follow,
	// on #riff as data-riff-cue for what reads it (the level lamps, level.js; the tests). rest:
	// nothing asked of the deck. cueing: the press made, the platter pulled up and the arm carried
	// over its groove on the lever. hovering: over its groove, the lever not yet let down, until the
	// music can sound. down: lowered and landed, the music let go at that moment. playing: it sounds.
	// lifting: stopping, the music winding down with the platter before the lever lifts the arm.
	function phase( name ) {
		if ( root.dataset.riffCue !== name ) {
			root.dataset.riffCue = name;
		}
	}
	phase( 'rest' );
	// The lever let down: the stylus sinks onto the record and is in its groove LOWER later.
	function lever( arm ) {
		arm.dataset.riffUp = 'lowering';
		lever.lands = performance.now() + LOWER;
		clearTimeout( lever.done );
		lever.done = setTimeout( lowered, LOWER );
	}
	// Carried over the record with no music waiting on it (the record brought out, or turned over,
	// and nothing asked to play), the arm is lowered once it gets there; with music waiting, drop()
	// lowers it.
	function lowerOver( arm ) {
		clearTimeout( lowerOver.wait );
		lowerOver.wait = setTimeout(
			() => {
				if ( ! held() && arm.dataset.riffUp === '' ) {
					lever( arm );
				}
			},
			Math.max( 0, ( swing.until || 0 ) - performance.now() )
		);
	}
	// Hovered over the groove at most this long for the music's file: past it the lever is let
	// down anyway, and the music sounds as soon as it can.
	const HOVER = 400;
	// The drop, the one start every press of play, track or side goes through where the deck is
	// seen: once the arm is over its groove (carried there, not in the hand), the platter will be at
	// a crawl by the time the stylus lands (by `ready`), and the music's file can play through, the
	// lever is let down, and the music is let go (go()) as the stylus lands, from where it was
	// held, so none of it is skipped. Run by timers, never by frames, which stop in a tab out of
	// sight; and never held past the arm's carry and a hover and a lowering: then the music goes,
	// and the arm with it.
	function drop( m, go, ready = 0 ) {
		const id = ++drop.id;
		clearTimeout( drop.wait );
		const t0 = performance.now();
		const due = Math.max( t0 + Math.max( 0, ( swing.until || 0 ) - t0 ), ready - LOWER ) + HOVER + LOWER;
		let hovered = 0;
		// Its file fetched now (the element waits for a play to fetch it), so it is there when the
		// stylus is.
		if ( m.preload === 'none' ) {
			m.preload = 'auto';
			drop.fetched = m;
		}
		const step = () => {
			if ( id !== drop.id ) {
				return;
			}
			const arm = tonearmOf();
			const now = performance.now();
			const later = ( ms ) => ( drop.wait = setTimeout( step, Math.max( 1, Math.min( ms, due - now ) ) ) );
			if ( P.reduce() || root.dataset.riffDeck !== 'out' || ! arm || now >= due ) {
				lowered();
				go();
				return;
			}
			const carrying = Math.max( 0, ( swing.until || 0 ) - now );
			if ( carrying || 'riffHeld' in arm.dataset || ! ( 'riffDown' in arm.dataset ) ) {
				phase( 'cueing' );
				later( carrying || 50 );
				return;
			}
			if ( arm.dataset.riffUp === '' ) {
				phase( 'hovering' );
				hovered ||= now;
				if ( now < ready - LOWER || ( m.readyState < m.HAVE_ENOUGH_DATA && now - hovered < HOVER ) ) {
					later( 30 );
					return;
				}
				lever( arm );
			}
			if ( arm.dataset.riffUp === 'lowering' ) {
				later( Math.max( 0, ( lever.lands || 0 ) - now ) + 1 );
				return;
			}
			go();
		};
		step();
	}
	drop.id = 0;
	function turn( m, restart = false ) {
		// A followed host's start is made by Listen Together, when it is due.
		if ( P.holds( m, true ) ) {
			return;
		}
		clearTimeout( turn.wait );
		clearTimeout( turn.spin );
		drop.id++;
		clearTimeout( drop.wait );
		stowing++;
		// Play pressed while the music winds down: it is no longer stopping (P.status()), from this
		// press, not from the frame the wind-down's pull notices it has been cancelled.
		halt.going = null;
		// The stylus is in the run-out: the record is seen to once it has been lifted from there.
		if ( runout.until > performance.now() && seen() ) {
			cued( true );
			phase( 'cueing' );
			P.paint();
			turn.wait = setTimeout( () => turn( m ), runout.until - performance.now() + 20 );
			return;
		}
		// Whether the platter is turning with the music, the deck's own fact rather than the last
		// paint's: the music itself cannot say, since a new track's element is paused from the
		// moment its file is pointed at until it is heard, while the platter turns on through the
		// change (below, data-riff-turning holds from `playing` to `pause`).
		const turning = 'riffTurning' in root.dataset && root.dataset.riffDeck === 'out' && ! held();
		const flipping = flip.until > performance.now();
		const arriving = 'riffArriving' in root.dataset;
		// Another track asked for while the record turns (a key, the bar, a media key, the lock
		// screen), or the same one from its start (previous, well into it): as a deck does it. The
		// cue lever lifts the arm and the music stops with it; the arm is carried over the record to
		// the band's lead-in, taking as long as the way is long; the lever lowers it there (drop()),
		// and the music is heard once the stylus is in the groove. Asked again on the way, the arm
		// turns for the newer band from where it is, lifted once and lowered once. A track ending on
		// its own plays on into the next band, as a record does, and a band the hand has put the arm
		// on (land()) is heard at once.
		const id = String( P.track()?.id ?? '' );
		const skip =
			seen() &&
			( turning || coasting !== null || performance.now() - ( turn.stopped ?? -Infinity ) < 250 ) &&
			root.dataset.riffDeck === 'out' &&
			! flipping &&
			P.speed === 1 &&
			!! turn.heard &&
			( restart || id !== turn.heard ) &&
			// A track that ended on its own is followed by its next within the same moment.
			performance.now() - ended > 300 &&
			! arriving;
		if ( skip ) {
			const arm = tonearmOf();
			cued( true );
			phase( 'cueing' );
			if ( arm ) {
				arm.dataset.riffUp = '';
			}
			// The motor runs on under the lifted arm.
			if ( coasting === null ) {
				coast( 1, 1 );
			}
			P.paint();
			needle();
			drop( m, () => {
				cued( false );
				turn.heard = id;
				settle( m );
				phase( 'down' );
				m.play().catch( P.paint );
			} );
			return;
		}
		// At the listener's own speed the music keeps its pitch, which a platter coming up to speed
		// would bend, so it starts at once.
		if ( ! seen() || P.speed !== 1 || ( turning && ! P.ramping && ! flipping ) ) {
			turn.heard = id;
			lowered();
			cued( false );
			if ( coasting !== null ) {
				release();
			}
			settle( m );
			m.play().catch( P.paint );
			return;
		}
		// How long until the arm can be brought to the record: the record turned over or brought
		// out first. Wherever the arm is, drop() brings it down.
		let wait = 0;
		const arm = tonearmOf();
		// Set down off the record by the hand, on its rest: lifted and carried back over the groove
		// the music is at first.
		if ( rested && arm && root.dataset.riffDeck === 'out' && m.paused && ! flipping && ! arriving ) {
			rested = false;
			arm.dataset.riffUp = '';
			arm.dataset.riffDown = '';
			needle();
		}
		if ( flipping ) {
			wait = flip.until - performance.now();
		} else if ( arriving ) {
			wait = Math.max( 0, change.until - performance.now() ) + DROP + LAND;
		} else if ( root.dataset.riffDeck !== 'out' ) {
			deck( true );
			wait = DROP + LAND;
		}
		cued( true );
		phase( 'cueing' );
		P.paint();
		const go = () => {
			cued( false );
			if ( P.el() !== m ) {
				windDown();
				phase( 'rest' );
				return;
			}
			turn.heard = String( P.track()?.id ?? '' );
			phase( 'down' );
			const from = m.paused ? CRAWL : m.playbackRate;
			m.playbackRate = from;
			m.preservesPitch = m.webkitPreservesPitch = false;
			m.play()
				.then( () => bend( m, deckRate() ) )
				.then( ( whole ) => whole && settle( m ) )
				.catch( () => {
					// Unless another start has the platter by now.
					if ( ! held() ) {
						windDown();
					}
					P.paint();
				} );
		};
		// The platter is pulled up to a crawl as the arm comes over, the motor started with the
		// press (or once the record is turned over or out), and the music starts at the speed it
		// has reached, its pitch rising with it. Still turning as it winds down, it is pulled up
		// from where it is, at once, unless the record is being turned over or changed meanwhile.
		let ready = performance.now() + wait;
		if ( m.paused ) {
			const up = pull( coasting ?? 0, CRAWL );
			if ( coasting !== null && ! flipping && ! arriving ) {
				coast( coasting, CRAWL );
				ready = performance.now() + up;
			} else {
				turn.spin = setTimeout( () => coast( coasting ?? 0, CRAWL ), wait );
				ready += up;
			}
		}
		const start = () => drop( m, go, ready );
		if ( wait ) {
			turn.wait = setTimeout( start, wait );
		} else {
			start();
		}
	}
	// Previous, well into the track playing (playback.js): on the deck, its start as another
	// track's is, the arm lifted and carried back to the band's lead-in and lowered there, the music
	// silent on the way. Whether the deck took it; where it didn't, the music jumps there.
	function again( m ) {
		if ( m.paused || held() || ! seen() || root.dataset.riffDeck !== 'out' || P.speed !== 1 ) {
			return false;
		}
		m.pause();
		m.currentTime = 0;
		turn( m, true );
		return true;
	}
	function halt( m ) {
		// A followed host's stop is made by Listen Together, when it is due.
		if ( P.holds( m, false ) ) {
			return;
		}
		clearTimeout( turn.wait );
		clearTimeout( turn.spin );
		drop.id++;
		clearTimeout( drop.wait );
		clearTimeout( lever.done );
		const still = () => {
			raise();
			if ( ! held() ) {
				phase( 'rest' );
			}
		};
		if ( 'riffCued' in root.dataset ) {
			cued( false );
			phase( 'lifting' );
			if ( coasting !== null ) {
				coast( coasting, 0, still );
			} else {
				still();
			}
			P.paint();
			return;
		}
		if ( ! seen() || m.paused || P.speed !== 1 ) {
			settle( m );
			m.pause();
			raise();
			phase( 'rest' );
			return;
		}
		halt.going = m;
		phase( 'lifting' );
		bend( m, CRAWL ).then( ( whole ) => {
			halt.going = null;
			if ( whole ) {
				m.pause();
				settle( m );
				// The music stops at a crawl, and the platter turns on down to rest; only then
				// does the cue lever lift the stylus out of the groove.
				coast( CRAWL, 0, still );
			}
		} );
		P.paint();
	}
	// Whether play has been pressed and the music is waiting on the needle, or is winding down: the
	// controls show what was asked for.
	const held = () => 'riffCued' in root.dataset;

	// How long the cue lever takes to lower the arm onto the record: its silicone damping lets the
	// arm sink at one even speed, 8 mm a second, from 4 mm up, as a weight sinks through oil once it
	// has reached the speed the oil allows it, which takes it a millisecond. riff.css draws it with
	// the shadow under the arm coming in at that one speed.
	const LOWER = ( 4 / 8 ) * 1000;
	const stopping = () => !! halt.going && P.ramping;

	// ---- Out of the sleeve once the album plays, and not while a new one is arriving; it stays
	// out when paused. The arm follows the music wherever it goes, and the platter its speed: 33⅓
	// at the music's own, faster or slower with it, as a turntable's pitch changes both, one rate
	// set on the animation, which keeps it on the compositor.
	for ( const el of [ P.audio, P.video ] ) {
		el.addEventListener( 'playing', () => {
			if ( el === P.el() ) {
				root.dataset.riffTurning = '';
				release();
				phase( 'playing' );
			}
			// Back to fetching nothing until asked, as state.js set it, once drop() had it fetched.
			if ( drop.fetched === el ) {
				el.preload = 'none';
				drop.fetched = null;
			}
			if ( ! ( 'riffArriving' in root.dataset ) ) {
				deck( true );
			}
		} );
		el.addEventListener( 'pause', () => {
			if ( el === P.el() ) {
				// When, for a new track asked for at this moment (turn()): the record was turning.
				turn.stopped = performance.now();
				delete root.dataset.riffTurning;
				strobe();
				// Stopped some other way than by the deck (the track's end, another player, the
				// system): at rest, unless a start or a stop of the deck's own has it.
				if ( ! held() && root.dataset.riffCue !== 'lifting' ) {
					phase( 'rest' );
				}
			}
		} );
		el.addEventListener( 'ratechange', () => {
			if ( coasting === null ) {
				platter( el.playbackRate || 1 );
			}
		} );
		for ( const type of [ 'timeupdate', 'pause', 'playing', 'seeked', 'ratechange' ] ) {
			el.addEventListener( type, () => needle() );
		}
	}

	// ---- The tonearm: its stylus on the groove as far in as the side has played, from the
	// lead-in to the lead-out, so each angle is one moment of the side
	// and the arm creeps inward through every track, as a stylus tracking the groove does. The arm
	// turns on a base just off the record's corner (riff.css): in the record's own width, the base
	// at (1.05, 0.05), the arm pointing down at no turn, the centre at (0.5, 0.5). The turn that
	// puts the stylus at a distance from the centre is found by halving, since the stylus only
	// comes nearer the centre as the arm turns in.
	const BASE = [ 1.05, 0.05 ];
	const REST = -14;
	// The arm's length and its headshell's angle, set up as a deck's are, by Baerwald's alignment:
	// no tracking error where the stylus is 66 and 120.9 mm from the spindle. With the stylus r
	// from the spindle on an arm L long that turns d from it, the arm meets the groove's tangent
	// at the angle whose sine is (r² + L² − d²) / 2rL, and a headshell turned in by β puts the
	// stylus along the groove where that sine is sin β: where r² − 2rL·sin β + L² − d² = 0. The
	// nulls are its two roots, so r₁·r₂ = L² − d² and r₁ + r₂ = 2L·sin β. The base fixes d, so
	// L = √(d² + r₁r₂) and β = asin((r₁ + r₂) / 2L): with a 12-inch record 302 mm across, d is
	// 214.6 mm, L 232.5 mm (17.8 mm of overhang past the spindle) and β 23.7°.
	const MM = 302;
	const NULLS = [ 66, 120.9 ];
	const SPAN = Math.hypot( BASE[ 0 ] - 0.5, BASE[ 1 ] - 0.5 ) * MM;
	const LENGTH = Math.sqrt( SPAN * SPAN + NULLS[ 0 ] * NULLS[ 1 ] );
	const OFFSET = Math.asin( ( NULLS[ 0 ] + NULLS[ 1 ] ) / ( 2 * LENGTH ) );
	const ARM = LENGTH / MM;
	// For the deck as WebGL draws it (deck-gl.js), which stands its arm where this one is.
	P.arm = { base: BASE, length: ARM, offset: OFFSET, rest: REST };
	// Drawn to match, in the drawing's units (the record's hundredths, the base at (6, 4)): the
	// stylus on the line from the base, the headshell turned by β round it, and the tube's S
	// bending into the headshell's back along its line. The grip runs on to the stylus.
	function drawArm() {
		const tube = $( '.riff-arm-tube' );
		if ( ! tube ) {
			return;
		}
		const at = [ 6, 4 + 100 * ARM ];
		const along = [ -Math.sin( OFFSET ), Math.cos( OFFSET ) ];
		const back = ( k ) => [ at[ 0 ] - k * along[ 0 ], at[ 1 ] - k * along[ 1 ] ].map( ( n ) => n.toFixed( 2 ) ).join( ' ' );
		const path = `M6 -3V4C6 28 8.6 46 8.2 59C8.05 64 ${ back( 11.5 ) } ${ back( 7.5 ) }`;
		tube.querySelector( '.riff-arm-wand' )?.setAttribute( 'd', path );
		tube.querySelector( '.riff-arm-grip' )?.setAttribute( 'd', `${ path }L${ back( 0 ) }` );
		tube.querySelector( '.riff-headshell' )?.setAttribute(
			'transform',
			`translate(${ back( 0 ) }) rotate(${ ( ( OFFSET * 180 ) / Math.PI ).toFixed( 2 ) })`
		);
	}
	drawArm();
	// How far from the centre, as a share of the radius, the groove is once a share of the album
	// has played: playing time runs evenly across the radius.
	const groovedAt = ( played ) => LEAD_IN - ( LEAD_IN - leadOut() ) * played;
	function angle( played ) {
		const want = 0.5 * groovedAt( played );
		const away = ( deg ) => {
			const r = ( deg * Math.PI ) / 180;
			return Math.hypot( BASE[ 0 ] - ARM * Math.sin( r ) - 0.5, BASE[ 1 ] + ARM * Math.cos( r ) - 0.5 );
		};
		let lo = 0;
		let hi = 50;
		for ( let i = 0; i < 20; i++ ) {
			const mid = ( lo + hi ) / 2;
			if ( away( mid ) > want ) {
				lo = mid;
			} else {
				hi = mid;
			}
		}
		return lo;
	}

	// Seconds into the side playing, and its length; null until the album's tracks are known. Until
	// the element holds the new track's file, the track has not begun.
	function where() {
		const album = albums.get( playing );
		const t = P.track();
		const on = sideOf( t );
		if ( ! on ) {
			return null;
		}
		const m = P.el();
		const file = m.getAttribute( 'src' );
		const into = file && ( file === P.songSrc( t ) || file === t.video?.src ) ? m.currentTime || 0 : 0;
		const at = album.ids.indexOf( String( t.id ) );
		return { now: Math.min( on.length, album.starts[ at ] - on.start + into ), length: on.length, key: `${ playing }:${ on.name }`, m };
	}

	// The sweep: one animation of the arm's turn across the whole album, its keyframes the angle at
	// each point of it, its clock held to the music's. It runs on the compositor, so the arm moves
	// every frame without a line of script, and pauses, seeks and changes speed with the music.
	// Where the music jumps, a new track or a seek, the arm is carried there on a hand's path (its
	// tube turns from where the arm was to nothing) rather than leaping.
	let sweep = null;
	let swept = '';
	const shown = ( arm ) => parseFloat( getComputedStyle( arm ).rotate ) || 0;
	// How long the carry takes: the hand or the cue lever crosses the record at an even pace, a band
	// or so (about 3.5°) in LAND, the whole side in about two seconds.
	const carry = ( degrees ) => 350 + 70 * Math.abs( degrees );
	// Taken off the record to turn it over, the arm is moved by the hand alone, briskly: the whole
	// of its way from the run-out to its rest in about 0.7 s. Put back over the new side, with more
	// care: from its rest to the lead-in in about 0.8 s, so that, lowered, it lands as the music has
	// always started after a side, about 7.2 s after the last one ended.
	const brisk = ( degrees ) => 200 + 10 * Math.abs( degrees );
	const careful = ( degrees ) => 200 + 23 * Math.abs( degrees );
	function swing( arm, from, to, pace = carry ) {
		const tube = arm.querySelector( '.riff-arm-tube' );
		// Carried again on the way: from where the tube is now, not from where it set out.
		const before = parseFloat( tube ? getComputedStyle( tube ).rotate : '' ) || 0;
		swing.anim?.cancel();
		const under = before - ( parseFloat( tube ? getComputedStyle( tube ).rotate : '' ) || 0 );
		swing.anim = null;
		swing.until = 0;
		if ( Math.abs( from + under - to ) < 0.2 || P.reduce() || ! tube ) {
			return;
		}
		const duration = pace( from + under - to );
		swing.anim = tube.animate( [ { rotate: `${ ( from + under - to ).toFixed( 2 ) }deg` }, { rotate: '0deg' } ], { duration, easing: hand(), composite: 'add' } );
		swing.until = performance.now() + duration;
	}
	function lift() {
		const arm = $( '.riff-arm' );
		delete arm?.dataset.riffUp;
		if ( sweep && arm ) {
			const from = shown( arm );
			sweep.cancel();
			swing( arm, from, REST );
		}
		runout.anim?.cancel();
		runout.anim = null;
		sweep = null;
		swept = '';
	}
	function needle( at = false, pace = carry ) {
		const arm = $( '.riff-arm' );
		const w = where();
		// In the hand, it is where the hand holds it; in the run-out, where the groove takes it.
		if ( ! arm || ! w || 'riffHeld' in arm.dataset || runout.until ) {
			return;
		}
		if ( P.reduce() || ! ( 'riffDown' in arm.dataset ) ) {
			arm.style.setProperty( '--riff-arm', `${ angle( w.now / w.length ).toFixed( 2 ) }deg` );
			return;
		}
		const { key } = w;
		const ms = w.now * 1000;
		if ( ! sweep || swept !== key ) {
			const from = shown( arm );
			sweep?.cancel();
			const frames = [];
			for ( let i = 0; i <= 96; i++ ) {
				frames.push( { rotate: `${ angle( i / 96 ).toFixed( 3 ) }deg` } );
			}
			sweep = arm.animate( frames, { duration: w.length * 1000, fill: 'both' } );
			swept = key;
			sweep.currentTime = ms;
			if ( ! at && ! needle.place ) {
				swing( arm, from, angle( w.now / w.length ), pace );
			}
			needle.place = false;
		} else if ( Math.abs( sweep.currentTime - ms ) > 300 ) {
			const from = shown( arm );
			sweep.currentTime = ms;
			swing( arm, from, angle( w.now / w.length ), pace );
		}
		if ( sweep.playbackRate !== ( w.m.playbackRate || 1 ) ) {
			sweep.updatePlaybackRate( w.m.playbackRate || 1 );
		}
		if ( w.m.paused ) {
			sweep.pause();
		} else if ( sweep.playState !== 'running' ) {
			sweep.play();
		}
	}

	// ---- The parts at hand. Tapping the sleeve puts the record away, as a hand does: the arm back
	// on its rest, the platter wound down, the record into the sleeve. Tapped again, the record
	// comes out and plays. Pressing play anywhere does the same once it is away.
	const sleeve = $( '.riff-sleeve' );
	function stand( out ) {
		$( '.riff-mount' )?.toggleAttribute( 'inert', ! out );
		if ( sleeve ) {
			sleeve.textContent = out ? __( 'Put the record away' ) : __( 'Play the record' );
		}
	}
	function stow() {
		P.press( 'toggle' );
		const m = P.el();
		if ( root.dataset.riffDeck !== 'out' ) {
			turn( m );
			return;
		}
		const token = ++stowing;
		delete $( '.riff-arm' )?.dataset.riffDown;
		lift();
		const away = () => token === stowing && deck( false );
		if ( m.paused || held() ) {
			halt( m );
			away();
			return;
		}
		m.addEventListener( 'pause', away, { once: true } );
		halt( m );
	}
	sleeve?.addEventListener( 'click', stow );
	$( '.riff-cover' )?.addEventListener( 'click', () => {
		if ( sleeve?.checkVisibility() ) {
			stow();
		}
	} );

	// The arm, picked up and put down anywhere on the side: the stylus lands in the groove under
	// it, at the moment of the side that groove holds, the inverse of angle(). Dragged, it turns on
	// its base under the hand, keeping the point it was taken by; clicked, it is picked up and follows the pointer until the next click puts it down,
	// so a single pointer can move it without dragging (WCAG 2.5.7). For a keyboard it is a slider
	// over the side's bands: the arrows put it at the lead-in of the band before or after, Home
	// and End at the first and last.
	const tonearm = $( '.riff-arm' );
	// Where a point on the screen lies around the arm's base, as the arm's own angle: 0 straight
	// down, turning towards the record as it grows.
	function around( sx, sy ) {
		// Where the deck is drawn from a chair (deck-gl.js), in the arm's plane on the page's flat deck.
		const [ x, y ] = P.flat ? P.flat( sx, sy, 'arm' ) : [ sx, sy ];
		const r = $( '.riff-record' ).getBoundingClientRect();
		const dx = x - r.left - BASE[ 0 ] * r.width;
		const dy = y - r.top - BASE[ 1 ] * r.width;
		return ( Math.atan2( -dx, dy ) * 180 ) / Math.PI;
	}
	// The share of the side under the stylus with the arm at an angle, from its distance to the
	// record's centre.
	function playedOf( deg ) {
		const r = ( deg * Math.PI ) / 180;
		const out = Math.hypot( BASE[ 0 ] - ARM * Math.sin( r ) - 0.5, BASE[ 1 ] + ARM * Math.cos( r ) - 0.5 ) / 0.5;
		return Math.min( 1, Math.max( 0, ( LEAD_IN - out ) / ( LEAD_IN - leadOut() ) ) );
	}
	// In the hand: turned by as much as the hand has turned round the base since it took the arm,
	// from its rest to the end of the side.
	let grip = null;
	function take( x, y ) {
		grip = { deg: shown( tonearm ), at: around( x, y ) };
	}
	function hold( x, y ) {
		sweep?.cancel();
		sweep = null;
		swept = '';
		// Picked up, the stylus leaves the groove and the music is gone with it, at once; the motor
		// runs on under the arm at the speed it had, and the music is heard again once the stylus is
		// set down in a groove (land()).
		if ( ! ( 'riffHeld' in tonearm.dataset ) ) {
			const m = P.el();
			grip.silenced = ! m.paused || held();
			if ( grip.silenced ) {
				clearTimeout( turn.wait );
				clearTimeout( turn.spin );
				drop.id++;
				clearTimeout( drop.wait );
				cued( true );
				phase( 'cueing' );
				if ( coasting === null ) {
					coast( m.playbackRate || 1, m.playbackRate || 1 );
				}
				m.pause();
			}
		}
		rested = false;
		tonearm.dataset.riffHeld = '';
		delete tonearm.dataset.riffDown;
		grip.raw = grip.deg + around( x, y ) - grip.at;
		grip.now = Math.min( angle( 1 ), Math.max( REST, grip.raw ) );
		tonearm.style.setProperty( '--riff-arm', `${ grip.now.toFixed( 2 ) }deg` );
		point( playedOf( grip.now ), x, y );
	}
	// The band a moment of the side is in, and how far into it.
	function bandAt( played ) {
		const album = albums.get( playing );
		const on = sideOf( P.track() );
		const s = played * on.length;
		let k = on.from;
		while ( k + 1 < on.to && album.starts[ k + 1 ] - on.start <= s ) {
			k++;
		}
		return { k, into: Math.max( 0, s - ( album.starts[ k ] - on.start ) ) };
	}
	// The needle down on a band: the track playing moves; another in the queue is loaded there,
	// playing if the music was. A band whose track is not in the queue leaves the music alone.
	function land( k, into = 0, resume = false ) {
		P.press( 'seek' );
		unpoint();
		rested = false;
		delete tonearm.dataset.riffHeld;
		if ( root.dataset.riffDeck === 'out' ) {
			tonearm.dataset.riffDown = '';
		}
		const album = albums.get( playing );
		const id = String( album.ids[ k ] );
		const m = P.el();
		// Put there by the hand: heard as soon as it plays, with no carry of its own (turn()).
		turn.heard = id;
		if ( id === String( P.track().id ) ) {
			m.currentTime = into;
		} else {
			const i = P.order.findIndex( ( q ) => String( P.queue[ q ].id ) === id );
			if ( i >= 0 ) {
				const play = ( ! m.paused || held() ) && ! resume;
				P.stopAll();
				P.pos = i;
				P.load( { play, at: into } );
			}
		}
		needle();
		// Set down by the hand on the music it lifted off: heard from the groove it is in, now that
		// the stylus is down, at the speed the platter turned on at.
		if ( resume ) {
			cued( false );
			const now = P.el();
			turn.heard = String( P.track()?.id ?? '' );
			settle( now );
			now.play().catch( P.paint );
		}
	}
	// A press on the grooves while the record plays, as a deck's cue lever does it: the lever lifts
	// the arm and the music stops with it; the arm is carried over the record to the groove pressed,
	// taking as long as the way is long; the lever lowers it there, and the music is heard from
	// there once the stylus is in the groove. Pressed again on the way, the arm turns for the newer
	// groove from where it is, lifted once and lowered once. Stopped, the arm is put there.
	function cueTo( k, into ) {
		const m = P.el();
		const arm = tonearm;
		const album = albums.get( playing );
		const i = P.order.findIndex( ( q ) => String( P.queue[ q ].id ) === String( album.ids[ k ] ) );
		const same = String( album.ids[ k ] ) === String( P.track().id );
		if ( ! ( ! m.paused || held() ) || root.dataset.riffDeck !== 'out' || P.reduce() || P.speed !== 1 || 'riffHeld' in arm.dataset || ( ! same && i < 0 ) ) {
			land( k, into );
			return;
		}
		P.press( 'seek' );
		clearTimeout( turn.wait );
		clearTimeout( turn.spin );
		halt.going = null;
		cued( true );
		phase( 'cueing' );
		arm.dataset.riffUp = '';
		arm.dataset.riffDown = '';
		if ( coasting === null ) {
			coast( m.playbackRate || 1, m.playbackRate || 1 );
		}
		settle( m );
		m.pause();
		if ( same ) {
			m.currentTime = into;
		} else {
			P.stopAll();
			P.pos = i;
			P.load( { play: false, at: into } );
		}
		needle();
		P.paint();
		const now = P.el();
		drop( now, () => {
			cued( false );
			turn.heard = String( P.track()?.id ?? '' );
			settle( now );
			phase( 'down' );
			now.play().catch( P.paint );
		} );
	}
	// ---- What lies in a groove of the side, said beside the pointer: the band, its title and the
	// moment in it, which is where the needle would land. The arm in the hand says it for the
	// groove under its stylus. A mouse or a pen over the record says it for the groove it points
	// at, and a press there puts the needle down in it: the same moment the arm's own angle
	// stands for (angle()), so the stylus comes to rest on the point pressed. A finger has the
	// arm; a touch on the record is too easily one meant for something else. The record WebGL
	// draws marks the groove too (deck-gl.js, P.cueAt, as a share of the radius).
	const cue = $( '.riff-cue' );
	const said = document.createElement( 'span' );
	said.className = 'riff-cue-tip';
	said.setAttribute( 'aria-hidden', 'true' );
	said.hidden = true;
	np.append( said );
	function point( played, x, y ) {
		const on = sideOf( P.track() );
		if ( ! on ) {
			unpoint();
			return;
		}
		const { k, into } = bandAt( played );
		const box = np.getBoundingClientRect();
		said.textContent = `${ on.name }${ k - on.from + 1 } ${ albums.get( playing ).titles[ k ] } · ${ time( into ) }`;
		said.style.translate = `${ ( x - box.left ).toFixed( 1 ) }px ${ ( y - box.top ).toFixed( 1 ) }px`;
		said.hidden = false;
		P.cueAt = groovedAt( played );
	}
	function unpoint() {
		said.hidden = true;
		P.cueAt = null;
	}
	if ( cue ) {
		// The share of the side in the groove under a point of the screen; null off the grooves.
		const under = ( e ) => {
			// The cue's own box on the page's flat deck, which the plinth's is, and the point there.
			const r = ( P.flat ? $( '.riff-plinth' ) : cue ).getBoundingClientRect();
			const [ x, y ] = P.flat ? P.flat( e.clientX, e.clientY ) : [ e.clientX, e.clientY ];
			const out = Math.hypot( x - r.left - r.width / 2, y - r.top - r.height / 2 ) / ( r.width / 2 );
			return out > LEAD_IN || out < leadOut() || ! sideOf( P.track() ) ? null : ( LEAD_IN - out ) / ( LEAD_IN - leadOut() );
		};
		let down = null;
		cue.addEventListener( 'pointermove', ( e ) => {
			if ( grip || e.pointerType === 'touch' ) {
				return;
			}
			const played = under( e );
			cue.toggleAttribute( 'data-riff-over', played !== null );
			if ( played === null ) {
				unpoint();
			} else {
				point( played, e.clientX, e.clientY );
			}
		} );
		cue.addEventListener( 'pointerleave', () => {
			down = null;
			cue.removeAttribute( 'data-riff-over' );
			if ( ! grip ) {
				unpoint();
			}
		} );
		cue.addEventListener( 'pointerdown', ( e ) => {
			if ( e.pointerType === 'touch' || e.button !== 0 || under( e ) === null ) {
				return;
			}
			e.stopPropagation();
			down = { x: e.clientX, y: e.clientY };
		} );
		cue.addEventListener( 'pointerup', ( e ) => {
			const played = under( e );
			const pressed = down && played !== null && Math.hypot( e.clientX - down.x, e.clientY - down.y ) <= 4;
			down = null;
			if ( ! pressed ) {
				return;
			}
			const { k, into } = bandAt( played );
			cueTo( k, into );
			point( played, e.clientX, e.clientY );
		} );
	}
	// ---- The deck's keys under the hand (player.php), as a deck's are. Pressed and let go, the
	// track keys go to the track before or after; held, they wind the music back or on, slowly
	// at first and then faster, for as long as they are held, and the stylus goes with it. Where
	// a device can, each key gives a tick under the finger as it goes down.
	for ( const [ key, way ] of [ [ $( '.riff-key-prev' ), -1 ], [ $( '.riff-key-next' ), 1 ] ] ) {
		if ( ! key ) {
			continue;
		}
		let wait = 0;
		let winding = 0;
		let wound = false;
		const letGo = () => {
			clearTimeout( wait );
			clearInterval( winding );
			wait = winding = 0;
		};
		key.addEventListener( 'pointerdown', ( e ) => {
			if ( e.button !== 0 ) {
				return;
			}
			letGo();
			wound = false;
			key.setPointerCapture?.( e.pointerId );
			wait = setTimeout( () => {
				let turns = 0;
				wound = true;
				winding = setInterval( () => {
					const m = P.el();
					if ( Number.isFinite( m.duration ) ) {
						m.currentTime = Math.min( m.duration - 0.25, Math.max( 0, m.currentTime + way * Math.min( 8, 1 + 0.25 * turns++ ) ) );
					}
				}, 120 );
			}, 450 );
		} );
		for ( const over of [ 'pointerup', 'pointercancel', 'lostpointercapture' ] ) {
			key.addEventListener( over, letGo );
		}
		// A key that wound the music is not also a press of it.
		key.addEventListener( 'click', ( e ) => {
			if ( wound ) {
				wound = false;
				e.stopPropagation();
				e.preventDefault();
			}
		} );
	}
	// The transport is the bar's own or the deck's keys, never both: the deck on its own has no
	// bar (immerse()). When the one that has the focus goes, as the stage becomes the deck, the
	// record is put away or a video takes the stage, the focus goes to the same control where it
	// now is, rather than nowhere. And the deck's speed
	// is asked again, since it holds only while the deck is the view (deckOnly()).
	const transport = ( b ) => b?.closest?.( '.riff-bar-transport, .riff-keys' );
	const inSight = ( b ) =>
		b.offsetParent !== null && ! b.closest( '[inert]' ) && getComputedStyle( b ).visibility !== 'hidden';
	let pressedOn = null;
	root.addEventListener( 'focusin', ( e ) => {
		const b = e.target.closest?.( '[data-riff-action]' );
		pressedOn = transport( b ) ? b : null;
	} );
	new MutationObserver( () => {
		retune( false );
		requestAnimationFrame( () => {
			const lost = pressedOn && ! inSight( pressedOn ) && [ document.body, pressedOn ].includes( document.activeElement );
			if ( lost ) {
				$$( `[data-riff-action="${ pressedOn.dataset.riffAction }"]` )
					.find( ( b ) => b !== pressedOn && transport( b ) && inSight( b ) )
					?.focus();
			}
		} );
	} ).observe( root, {
		attributeFilter: [ 'data-riff-deck', 'data-riff-turntable', 'data-mode', 'data-riff-showing' ],
	} );
	new MutationObserver( () => retune( false ) ).observe( np, { attributeFilter: [ 'hidden' ] } );
	$( '.riff-keys' )?.addEventListener( 'pointerdown', ( e ) => {
		if ( e.target.closest( 'button' ) && e.pointerType === 'touch' ) {
			navigator.vibrate?.( 8 );
		}
	} );
	// The slider's value: the band playing, by its number on the side.
	function bands() {
		const album = albums.get( playing );
		const on = sideOf( P.track() );
		if ( ! tonearm || ! on ) {
			return;
		}
		const k = album.ids.indexOf( String( P.track().id ) );
		tonearm.setAttribute( 'aria-valuemax', String( on.to - on.from ) );
		tonearm.setAttribute( 'aria-valuenow', String( k - on.from + 1 ) );
		tonearm.setAttribute( 'aria-valuetext', `${ on.name }${ k - on.from + 1 } ${ album.titles[ k ] }` );
	}
	if ( tonearm ) {
		let from = null;
		let carried = false;
		const follow = ( e ) => hold( e.clientX, e.clientY );
		const put = ( e ) => {
			document.removeEventListener( 'pointermove', follow );
			hold( e.clientX, e.clientY );
			const { now, raw, silenced } = grip;
			grip = null;
			// Let go beyond the lead-in, off the record: back on its rest, and nothing is heard. The
			// platter winds down as it does when the music is stopped.
			if ( raw < angle( 0 ) - 1 ) {
				unpoint();
				rested = true;
				delete tonearm.dataset.riffHeld;
				if ( silenced ) {
					halt( P.el() );
				}
				P.paint();
				return;
			}
			const { k, into } = bandAt( playedOf( now ) );
			land( k, into, silenced );
		};
		tonearm.addEventListener( 'pointerdown', ( e ) => {
			if ( ! sideOf( P.track() ) || carried ) {
				return;
			}
			e.stopPropagation();
			e.preventDefault();
			tonearm.setPointerCapture( e.pointerId );
			from = { x: e.clientX, y: e.clientY, moved: false };
			take( e.clientX, e.clientY );
		} );
		tonearm.addEventListener( 'pointermove', ( e ) => {
			if ( ! from ) {
				return;
			}
			if ( Math.hypot( e.clientX - from.x, e.clientY - from.y ) > 4 ) {
				from.moved = true;
			}
			if ( from.moved ) {
				follow( e );
			}
		} );
		tonearm.addEventListener( 'pointerup', ( e ) => {
			if ( ! from ) {
				return;
			}
			const { moved } = from;
			from = null;
			if ( moved ) {
				put( e );
				return;
			}
			// Clicked: carried until the next press, wherever it is.
			carried = true;
			hold( e.clientX, e.clientY );
			document.addEventListener( 'pointermove', follow );
			document.addEventListener(
				'pointerdown',
				( down ) => {
					down.stopPropagation();
					down.preventDefault();
					carried = false;
					put( down );
				},
				{ capture: true, once: true }
			);
		} );
		tonearm.addEventListener( 'keydown', ( e ) => {
			const on = sideOf( P.track() );
			if ( ! on ) {
				return;
			}
			const k = albums.get( playing ).ids.indexOf( String( P.track().id ) );
			const back = document.dir === 'rtl' ? 'ArrowRight' : 'ArrowLeft';
			const ahead = document.dir === 'rtl' ? 'ArrowLeft' : 'ArrowRight';
			const to = {
				[ back ]: k - 1,
				ArrowDown: k - 1,
				[ ahead ]: k + 1,
				ArrowUp: k + 1,
				Home: on.from,
				End: on.to - 1,
			}[ e.key ];
			if ( to === undefined ) {
				return;
			}
			e.preventDefault();
			if ( to >= on.from && to < on.to && to !== k ) {
				land( to );
			}
		} );
	}

	// ---- The deck's own controls among its keys: the two speeds and the pitch fader. The music plays at the speed chosen over the record's own (an LP at 45 runs
	// fast, as on a deck), times the pitch, ±8%; its pitch moves with it, as a record's does, and
	// the platter, the strobe and the arm follow the one rate (ratechange, above). Where the
	// turntable isn't the view, the music plays at its own speed.
	const RPM = { 33: 100 / 3, 45: 45 };
	const own = () => ( root.dataset.riffFormat === '7' ? '45' : '33' );
	function deckOnly() {
		// Only while the deck is the view: closed, or on a video, the music is at its own speed,
		// rather than fast or slow with no control in sight that says why.
		if ( ! roomy() || np.hidden || P.isVideo?.() ) {
			return 1;
		}
		return ( RPM[ chosen ?? own() ] / RPM[ own() ] ) * ( 1 + pitch / 100 );
	}
	// The deck's speed times the listener's own (respeed(), above).
	function deckRate() {
		return deckOnly() * P.speed;
	}
	const fader = $( '[data-riff-pitch]' );

	// A control with a default (data-riff-default) has a key in its parent that sends it back there
	// (data-riff-reset), as a deck has one by its pitch fader's zero. The key is offered only while
	// the control is off its default and the listener is at it: the pointer within a finger's breadth
	// of it, the keyboard's focus on it or on its key, or a finger on it a moment ago. Offered, it is
	// data-riff-offered, which riff.css shows and deck-gl.js raises from the plinth; otherwise it is
	// out of reach and unheard. A double press on the control, or its 0 key, does the same.
	const NEAR = 32;
	const TOUCHED = 2500;
	const pointer = { x: -1e4, y: -1e4 };
	const resets = $$( '[data-riff-default]' ).flatMap( ( control ) => {
		const key = control.parentElement.querySelector( '[data-riff-reset]' );
		return key ? [ { control, key, touched: -TOUCHED, tapped: 0 } ] : [];
	} );
	const apart = ( b ) => Math.hypot( Math.max( b.left - pointer.x, 0, pointer.x - b.right ), Math.max( b.top - pointer.y, 0, pointer.y - b.bottom ) );
	function offer() {
		for ( const r of resets ) {
			const { control, key } = r;
			const offered = key.hasAttribute( 'data-riff-offered' );
			const at = document.activeElement;
			const near =
				( control.parentElement.contains( at ) && at.matches( ':focus-visible' ) ) ||
				performance.now() - r.touched < TOUCHED ||
				apart( control.getBoundingClientRect() ) <= NEAR ||
				( offered && apart( key.getBoundingClientRect() ) <= NEAR );
			const now = near && Number( control.value ) !== Number( control.dataset.riffDefault );
			if ( now !== offered ) {
				key.toggleAttribute( 'data-riff-offered', now );
			}
		}
	}
	function reset( r ) {
		// The key goes once the control is back, so the focus goes to the control, which says where it is.
		if ( r.key.contains( document.activeElement ) ) {
			r.control.focus();
		}
		r.control.value = r.control.dataset.riffDefault;
		r.control.dispatchEvent( new Event( 'input', { bubbles: true } ) );
	}
	let looking = 0;
	np.addEventListener(
		'pointermove',
		( e ) => {
			if ( e.pointerType === 'touch' || ! resets.length ) {
				return;
			}
			[ pointer.x, pointer.y ] = [ e.clientX, e.clientY ];
			looking ||= requestAnimationFrame( () => {
				looking = 0;
				offer();
			} );
		},
		{ passive: true }
	);
	np.addEventListener( 'pointerleave', () => {
		[ pointer.x, pointer.y ] = [ -1e4, -1e4 ];
		offer();
	} );
	for ( const r of resets ) {
		r.key.addEventListener( 'click', () => reset( r ) );
		r.control.addEventListener( 'dblclick', () => reset( r ) );
		r.control.addEventListener( 'keydown', ( e ) => {
			if ( e.key === '0' && ! e.altKey && ! e.ctrlKey && ! e.metaKey ) {
				e.preventDefault();
				reset( r );
			}
		} );
		// A finger: the key for a moment after it lets go, and two taps close together are a double press.
		for ( const el of [ r.control, r.key ] ) {
			el.addEventListener( 'pointerup', ( e ) => {
				if ( e.pointerType !== 'touch' ) {
					return;
				}
				const now = performance.now();
				if ( el === r.control && now - r.tapped < 350 ) {
					reset( r );
				}
				r.tapped = el === r.control ? now : 0;
				r.touched = now;
				offer();
				setTimeout( offer, TOUCHED + 50 );
			} );
		}
		r.control.parentElement.addEventListener( 'focusin', offer );
		// Once the focus has landed: from the control to its key, the key stays.
		r.control.parentElement.addEventListener( 'focusout', () => setTimeout( offer ) );
	}

	function paintDeck() {
		for ( const b of $$( '[data-riff-speed]' ) ) {
			const on = b.dataset.riffSpeed === ( chosen ?? own() );
			b.setAttribute( 'aria-checked', String( on ) );
			b.tabIndex = on ? 0 : -1;
		}
		if ( ! fader ) {
			return;
		}
		fader.value = String( pitch );
		fader.setAttribute( 'aria-valuetext', `${ pitch > 0 ? '+' : '' }${ pitch.toFixed( 1 ) }%` );
		offer();
	}
	// The motor pulls the platter to the new speed while it turns; stopped, it starts there. A
	// listener's own turn of the speed or the pitch is a press; the deck coming or going as the
	// stage changes shape is not, so opening Now Playing doesn't stop following someone.
	function retune( pressed = true ) {
		if ( pressed ) {
			P.press( 'speed' );
		}
		paintDeck();
		const m = P.el();
		if ( m.paused || held() || P.ramping ) {
			m.defaultPlaybackRate = deckRate();
			return;
		}
		// The stage changed and the music's speed did not, so nothing is written to it. A pull to the
		// speed it already has would let go of its pitch and take it again a frame or two later,
		// which is heard as a break in the music. The platter and the arm still take its rate, as the
		// pull would have given it them, since no ratechange comes to do it.
		if ( settled( m ) ) {
			drive( m.playbackRate );
			return;
		}
		bend( m, deckRate() ).then( ( whole ) => whole && settle( m ) );
	}
	// The speeds are a radio group, wherever they stand: a press chooses one, and the arrows move
	// between them.
	for ( const speeds of $$( '.riff-speeds' ) ) {
		speeds.addEventListener( 'click', ( e ) => {
			const speed = e.target.closest( '[data-riff-speed]' );
			if ( speed ) {
				chosen = speed.dataset.riffSpeed;
				retune();
			}
		} );
		speeds.addEventListener( 'keydown', ( e ) => {
			if ( ! [ 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown' ].includes( e.key ) ) {
				return;
			}
			e.preventDefault();
			chosen = ( chosen ?? own() ) === '33' ? '45' : '33';
			retune();
			speeds.querySelector( `[data-riff-speed="${ chosen }"]` ).focus();
		} );
	}
	if ( fader ) {
		// Under a hand it clicks into the middle, as a fader's centre detent does; the keyboard's
		// steps of 0.1 go where they say.
		let gripped = false;
		fader.addEventListener( 'pointerdown', () => ( gripped = true ) );
		for ( const type of [ 'pointerup', 'pointercancel' ] ) {
			window.addEventListener( type, () => ( gripped = false ), { passive: true } );
		}
		fader.addEventListener( 'input', () => {
			const v = Number( fader.value );
			pitch = gripped && Math.abs( v ) < 0.3 ? 0 : v;
			retune();
		} );
	}
	paintDeck();

	// The side's grooves: a glossy ring between each of its tracks, and, where something has measured
	// a track's loudness (its levels, a digit from 0 to 9 for each moment of it), the band lighter
	// where the music is loud, as a cut groove is: a loud passage swings the stylus wider, so its
	// walls catch more of the light. At most 24 shades a track, each at the radius its moment is
	// cut at, so a side's gradient stays a few hundred stops.
	function cut( on ) {
		const record = $( '.riff-record' );
		const album = albums.get( playing );
		const lengths = on && album ? album.lengths.slice( on.from, on.to ) : [];
		const whole = lengths.reduce( ( a, b ) => a + b, 0 );
		// The same side for the record WebGL draws (deck-gl.js), which reads it at its next frame.
		P.pressed = whole ? { lengths, levels: lengths.map( ( _, k ) => album.levels?.[ on.from + k ] || '' ) } : null;
		if ( ! record || ! whole ) {
			record?.style.removeProperty( '--riff-bands' );
			return;
		}
		const pc = ( share ) => `${ ( 100 * groovedAt( share ) ).toFixed( 2 ) }%`;
		const layers = [];
		if ( lengths.length > 1 ) {
			const stops = [];
			let played = 0;
			for ( const length of lengths.slice( 0, -1 ) ) {
				played += length;
				const at = 100 * groovedAt( played / whole );
				stops.unshift(
					`transparent ${ ( at - 0.35 ).toFixed( 2 ) }%, rgb(255 255 255 / 0.09) ${ ( at - 0.35 ).toFixed( 2 ) }% ${ ( at + 0.35 ).toFixed( 2 ) }%, transparent ${ ( at + 0.35 ).toFixed( 2 ) }%`
				);
			}
			layers.push( `radial-gradient(circle closest-side, ${ stops.join( ', ' ) })` );
		}
		// From the lead-out outwards, as a gradient's stops run: the side's last moment first.
		const shades = [];
		let into = whole;
		for ( let k = lengths.length - 1; k >= 0; k-- ) {
			into -= lengths[ k ];
			const levels = album.levels?.[ on.from + k ] || '';
			if ( ! levels ) {
				shades.push( `transparent ${ pc( ( into + lengths[ k ] ) / whole ) } ${ pc( into / whole ) }` );
				continue;
			}
			const n = Math.min( 24, levels.length );
			for ( let j = n - 1; j >= 0; j-- ) {
				// The loudest of the moments this shade stands for.
				const part = levels.slice( Math.floor( ( j * levels.length ) / n ), Math.floor( ( ( j + 1 ) * levels.length ) / n ) );
				const loud = Math.max( ...[ ...part ].map( Number ) ) / 9;
				shades.push( `rgb(255 255 255 / ${ ( 0.06 * loud ).toFixed( 3 ) }) ${ pc( ( into + ( ( j + 0.5 ) * lengths[ k ] ) / n ) / whole ) }` );
			}
		}
		if ( shades.some( ( shade ) => shade.startsWith( 'rgb' ) ) ) {
			layers.push(
				`radial-gradient(circle closest-side, transparent ${ pc( 1 ) }, ${ shades.join( ', ' ) }, transparent ${ pc( 0 ) })`
			);
		}
		if ( layers.length ) {
			record.style.setProperty( '--riff-bands', layers.join( ', ' ) );
		} else {
			record.style.removeProperty( '--riff-bands' );
		}
	}

	// ---- While a video plays in Now Playing, the Song and Video switch and the bar fade away after
	// a stretch with nothing from the listener, as a video player's controls do; any pointer move,
	// key, touch or focus brings them back at once. They stay while the video is paused, while a
	// panel is open beside it, while keyboard focus is in them and while a mouse is over them, so
	// focus is never under a hidden bar and nothing is reached by hovering alone. Focus a click or
	// tap leaves on a button, and the hover a tap leaves behind, don't hold them: the next key
	// wakes them before it acts. Fullscreen is the browser's own. riff.css fades them,
	// or, where less motion is asked for, shows and hides them at once.
	// Three seconds: time to reach for a control after the last move, and soon enough that the
	// picture is left clear.
	const IDLE = 3000;
	const bar = $( '.riff-bar' );
	const modes = $( '.riff-modes' );
	const wayOut = $( '.riff-np-head [data-riff-action="close"]' );
	let idle = 0;
	let mouse = false;
	// The same holds for the deck on its own (immerse()), playing or not: the way out of it, at
	// the top of the desk, goes quiet with the rest, and the deck is the picture (riff.css).
	const watching = () =>
		! np.hidden &&
		root.classList.contains( 'is-open' ) &&
		! P.panelOpen &&
		!! P.views?.get( P.showing )?.stage &&
		( P.isVideo?.() ? ! P.video.paused : alone );
	const focused = ( el ) =>
		el.contains( document.activeElement ) &&
		document.activeElement.matches( ':focus-visible' );
	// The way out holds them only where it goes quiet with them: over a video it stays, and a
	// pointer left on it must not keep the bar and the switch over the picture.
	const inUse = () =>
		[ bar, modes, alone && wayOut ].some(
			( el ) => el && ( focused( el ) || ( mouse && el.matches( ':hover' ) ) )
		);
	document.addEventListener(
		'pointermove',
		( e ) => {
			mouse = e.pointerType === 'mouse';
		},
		{ capture: true, passive: true }
	);
	function rest() {
		if ( ! watching() ) {
			return;
		}
		if ( inUse() ) {
			idle = setTimeout( rest, IDLE );
		} else {
			root.dataset.riffIdle = '';
		}
	}
	function wake() {
		clearTimeout( idle );
		delete root.dataset.riffIdle;
		if ( watching() ) {
			idle = setTimeout( rest, IDLE );
		}
	}
	for ( const ev of [ 'pointermove', 'pointerdown', 'keydown', 'wheel', 'touchstart', 'focusin' ] ) {
		document.addEventListener( ev, wake, { capture: true, passive: true } );
	}
	for ( const ev of [ 'play', 'pause', 'ended' ] ) {
		P.video.addEventListener( ev, wake );
		P.audio.addEventListener( ev, wake );
	}
	new MutationObserver( wake ).observe( root, { attributeFilter: [ 'data-riff-deck' ] } );
	root.addEventListener( 'riff:track', wake );
	P.wakeControls = wake;

	return {
		open,
		close,
		setView,
		tint,
		groove,
		deck,
		turn,
		again,
		halt,
		held,
		stopping,
		respeed,
		deckAlone: () => alone,
	};
}
