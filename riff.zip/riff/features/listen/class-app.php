<?php
/**
 * The app: a block, with a shortcode alias, that turns the page it sits on into the place to listen.
 *
 * @since 4.0.0
 * @package Riff
 */

namespace Riff\Listen;

use WP_Post;
use WP_Term;

use Riff\Catalog;
use Riff\Library;
use Riff\Player;
use Riff\Protect;
use Riff\Tracks;

defined( 'ABSPATH' ) || exit;

/**
 * The listening page.
 *
 * The page holding the block is the route, the way a shop plugin's shop page is. Inside it the
 * library and every post open without leaving the page, so the music never stops. The server
 * renders the first view, so the page reads without the script and search engines see the posts.
 * A post is addressed by ?riff={id} or ?riff={slug} on the same page, and the library through its
 * Nth page by ?riff_page={N}.
 */
final class App {

	/**
	 * The page template that is the block and nothing else, for a page that should be all player.
	 * Registered on block themes (WordPress 6.7 and newer); a page picks it under Template, which
	 * stores the slug, "listen", in its page template meta.
	 *
	 * @since 4.0.0
	 */
	public const TEMPLATE = 'riff//listen';

	/**
	 * The query argument that opens a post inside the app.
	 *
	 * @since 4.0.0
	 */
	public const QUERY = 'riff';

	/**
	 * The query argument that shows the library through a later page.
	 *
	 * @since 4.13.0
	 */
	public const PAGE_QUERY = 'riff_page';

	/**
	 * The query argument that leaves out the pages before it, for Load more, which already has them.
	 *
	 * @since 5.8.0
	 */
	public const FROM_QUERY = 'riff_from';

	/**
	 * The query argument, set to `view`, that answers with the app's bar and its view alone, as the
	 * app's script fetches a view: without the theme, the head or the footer it would throw away.
	 *
	 * @since 6.12.0
	 */
	public const PART = 'riff_part';

	/**
	 * Hooks the block and the shortcode.
	 *
	 * @since 4.0.0
	 */
	public static function register(): void {
		add_action( 'init', array( self::class, 'init' ) );
		// After Standalone's, so the app/ address is answered the same way.
		add_filter( 'template_include', array( self::class, 'part' ), 100 );
	}

	/**
	 * Answers ?riff_part=view on a Listen page with templates/view.php: the app's bar, its view and
	 * the document's title, which is all the app's script reads from a view it fetches. Anything
	 * else, or a page behind a password, keeps its template.
	 *
	 * @since 6.12.0
	 *
	 * @param string $template The template WordPress chose.
	 * @return string
	 */
	public static function part( $template ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which part of the page to send; nothing changes.
		if ( ! isset( $_GET[ self::PART ] ) || 'view' !== $_GET[ self::PART ] || ! is_page() || ! Player::enabled() ) {
			return $template;
		}
		$page = get_queried_object();
		if ( ! $page instanceof WP_Post || ! self::holds_app( $page ) || post_password_required( $page ) ) {
			return $template;
		}
		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex' );
		}
		return RIFF_DIR . 'templates/view.php';
	}

	/**
	 * Registers the block from its folder and the shortcode.
	 *
	 * @since 4.0.0
	 */
	public static function init(): void {
		register_block_type( RIFF_DIR . 'features/listen/block' );
		wp_set_script_translations( 'riff-app-editor-script', 'riff' );
		add_shortcode( 'riff', array( self::class, 'shortcode' ) );
		add_filter( 'document_title_parts', array( self::class, 'title_parts' ) );
		if ( function_exists( 'register_block_template' ) ) {
			register_block_template(
				self::TEMPLATE,
				array(
					'title'       => __( 'Listen', 'riff' ),
					'description' => __( 'The Riff block and nothing else: no header, no footer, the whole page is the player.', 'riff' ),
					'post_types'  => array( 'page' ),
					'content'     => '<!-- wp:riff/app {"align":"full"} /-->',
				)
			);
		}
	}

	/**
	 * Whether a post is a Listen page: it holds the Listen block, the [riff] shortcode or the
	 * Listen template.
	 *
	 * @since 5.7.0
	 *
	 * @param WP_Post $post Post.
	 * @return bool
	 */
	public static function holds_app( WP_Post $post ): bool {
		return Standalone::holds_player( $post ) || has_shortcode( $post->post_content, 'riff' );
	}

	/**
	 * Puts the view's name before the page's in the document title.
	 *
	 * Each view has its own address, so it has its own title too: a screen reader says it when the
	 * view opens, and a tab, a bookmark and the history list it by what is in it, not as Listen.
	 * The script copies the title across when it swaps views in place.
	 *
	 * @since 4.30.0
	 *
	 * @param array<string, string> $parts The title's parts.
	 * @return array<string, string>
	 */
	public static function title_parts( $parts ) {
		$page = get_queried_object();
		if ( ! is_array( $parts ) || ! $page instanceof WP_Post || ! self::holds_app( $page ) ) {
			return $parts;
		}
		$name = self::view_name();
		if ( '' !== $name ) {
			$parts['title'] = $name . ' ' . apply_filters( 'document_title_separator', '-' ) . ' ' . ( $parts['title'] ?? '' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core's own filter, applied as wp_get_document_title() does.
		}
		return $parts;
	}

	/**
	 * The name of the view the address opens, as its heading shows it; empty for Home.
	 *
	 * @return string
	 */
	private static function view_name(): string {
		$post = self::requested();
		if ( $post ) {
			return Library::title( $post );
		}
		$browse = Browse::requested();
		if ( ! $browse ) {
			return '';
		}
		switch ( $browse['view'] ) {
			case 'albums':
				return __( 'Albums', 'riff' );
			case 'artists':
				return __( 'Artists', 'riff' );
			case 'tracks':
				return __( 'Tracks', 'riff' );
			case 'posts':
				return __( 'Posts', 'riff' );
			case 'library':
				return __( 'Your Library', 'riff' );
			case 'playlist':
				// A listener's playlist is private: its name is only for whoever may read it.
				return current_user_can( 'read_post', $browse['id'] ) ? Library::title( $browse['id'] ) : __( 'Playlist', 'riff' );
			case 'album':
			case 'artist':
				$term = get_term( $browse['id'], 'album' === $browse['view'] ? Catalog::ALBUM : Catalog::ARTIST );
				return $term instanceof WP_Term ? Catalog::name( $term->name ) : '';
			default:
				if ( '' === $browse['search'] ) {
					return __( 'Search', 'riff' );
				}
				/* translators: %s: the words searched for. */
				return sprintf( __( 'Results for “%s”', 'riff' ), $browse['search'] );
		}
	}

	/**
	 * [riff], the same as the block.
	 *
	 * @since 4.0.0
	 * @return string
	 */
	public static function shortcode(): string {
		return self::render();
	}

	/**
	 * The app's markup, with the first view rendered on the server.
	 *
	 * @since 4.0.0
	 * @param array $attributes Block attributes.
	 * @param bool  $block      Whether the block's render.php asks, so the block's supports apply.
	 * @return string
	 */
	public static function render( array $attributes = array(), bool $block = false ): string {
		if ( ! Player::enabled() ) {
			return '';
		}
		// The app's own stylesheet, enqueued where it is used: a block theme renders the template
		// before the head prints, and a classic theme hoists a late style into the head.
		Player::styles();
		wp_enqueue_style( 'riff-app' );
		// In standalone mode every link stays under app/, so the player never drops back into the theme.
		$page   = Standalone::active() ? Standalone::url() : (string) get_permalink();
		$post   = self::requested();
		$browse = $post ? null : Browse::requested();
		if ( $post ) {
			$view = self::post_view( $post, $page );
		} elseif ( $browse ) {
			$view = Browse::view( $browse, $page );
		} else {
			$view = Home_View::view( $page );
		}
		$align = isset( $attributes['align'] ) && in_array( $attributes['align'], array( 'wide', 'full' ), true ) ? ' align' . $attributes['align'] : '';
		// Inside a block render the wrapper carries the block's supports (colours, type); the
		// shortcode has no block, so it gets the plain class. On a theme that sets its colours the
		// stylesheet mixes the quieter shades from them, under riff-app-themed.
		$tokens  = self::theme_tokens( $block ? $attributes : array() );
		$class   = 'riff-app' . ( isset( $tokens['--riff-app-bg'] ) || isset( $tokens['--riff-app-ink'] ) ? ' riff-app-themed' : '' );
		$style   = self::theme_style( $tokens );
		$wrapper = $block
			? get_block_wrapper_attributes(
				array_filter(
					array(
						'class' => $class,
						'style' => $style,
					)
				)
			)
			: 'class="' . esc_attr( $class . $align ) . '"' . ( $style ? ' style="' . esc_attr( $style ) . '"' : '' );
		if ( current_user_can( 'upload_files' ) ) {
			$wrapper .= sprintf( ' data-riff-media="%s" data-riff-nonce="%s"', esc_url( rest_url( 'wp/v2/media' ) ), esc_attr( wp_create_nonce( 'wp_rest' ) ) );
		}
		return sprintf(
			'<div %s data-riff-app data-riff-rest="%s" data-riff-tracks-rest="%s" data-riff-page="%s" data-riff-query="%s" data-riff-page-query="%s" data-riff-browse="%s">' .
			'<nav class="riff-app-bar" aria-label="%s">%s</nav>' .
			'<div class="riff-app-view" data-riff-app-view>%s</div></div>',
			$wrapper,
			esc_url( rest_url( Library::REST . '/library' ) ),
			esc_url( rest_url( Library::REST . '/tracks' ) ),
			esc_url( $page ),
			esc_attr( self::QUERY ),
			esc_attr( self::PAGE_QUERY ),
			// By name, so the script never reads one by its place in a list.
			esc_attr(
				(string) wp_json_encode(
					array(
						'view'     => Browse::VIEW,
						'album'    => Browse::ALBUM,
						'artist'   => Browse::ARTIST,
						'search'   => Browse::SEARCH,
						'filter'   => Browse::FILTER,
						'sort'     => Browse::SORT,
						'playlist' => Browse::PLAYLIST,
					)
				)
			),
			esc_attr( riff_brand()['name'] ),
			Browse::nav( $page, $browse ),
			$view
		);
	}

	/**
	 * The theme's colours and fonts, as the block's custom properties.
	 *
	 * A theme with a theme.json has its background, text, link colour and fonts in global
	 * styles; the block takes those, so it reads as part of the site. Styles > Blocks > Riff in the
	 * Site Editor comes before the site's own, and what is set on this one block before both. A
	 * theme without a theme.json keeps the block's own WordPress.org palette, unless the block
	 * itself is given colours or a font.
	 *
	 * Every view inside the block is drawn from these properties, so the block's colour and font
	 * settings are read here rather than printed on its wrapper (block.json skips their
	 * serialization): the shades of its rows and cards follow the colour chosen.
	 *
	 * @since 4.14.0
	 * @since 4.18.0 Styles > Blocks > Riff, and the block's own colour and font settings.
	 *
	 * @param array $attributes The block's attributes, when it is a block.
	 * @return array<string, string> Custom property values, keyed by name.
	 */
	public static function theme_tokens( array $attributes = array() ): array {
		$tokens = array();
		if ( wp_theme_has_theme_json() ) {
			$styles = array(
				'--riff-app-bg'           => array( 'color', 'background' ),
				'--riff-app-ink'          => array( 'color', 'text' ),
				'--riff-app-accent'       => array( 'elements', 'link', 'color', 'text' ),
				'--riff-app-font'         => array( 'typography', 'fontFamily' ),
				'--riff-app-heading-font' => array( 'elements', 'heading', 'typography', 'fontFamily' ),
			);
			foreach ( $styles as $token => $path ) {
				$value = wp_get_global_styles( $path, array( 'block_name' => 'riff/app' ) );
				$value = is_string( $value ) && '' !== $value ? $value : wp_get_global_styles( $path );
				if ( is_string( $value ) && '' !== $value ) {
					$tokens[ $token ] = $value;
				}
			}
		}
		$tokens = array_merge( $tokens, self::block_tokens( $attributes ) );
		if ( $tokens ) {
			// A link drawn in the text's own colour (Twenty Twenty-Five's is currentColor) is the
			// text colour: currentColor in a custom property resolves on the element using it, and
			// a filled button's would be its own label.
			if ( isset( $tokens['--riff-app-accent'], $tokens['--riff-app-ink'] ) && in_array( strtolower( $tokens['--riff-app-accent'] ), array( 'currentcolor', 'inherit' ), true ) ) {
				$tokens['--riff-app-accent'] = 'var(--riff-app-ink)';
			}
			// A theme that sets one font sets it for its headings too.
			if ( isset( $tokens['--riff-app-font'] ) && ! isset( $tokens['--riff-app-heading-font'] ) ) {
				$tokens['--riff-app-heading-font'] = 'var(--riff-app-font)';
			}
		}
		$tokens = Standalone::active() ? Standalone::tokens() : $tokens;
		return array_filter(
			$tokens,
			// A custom property name, and a value that cannot close the declaration or the attribute.
			static fn( $value, $token ): bool => is_string( $value ) && preg_match( '/^--riff-app-[a-z0-9-]+$/', (string) $token ) && preg_match( '/^[#a-z0-9(),.%\s"\'_-]+$/i', $value ),
			ARRAY_FILTER_USE_BOTH
		);
	}

	/**
	 * The colours and font set on one Riff block, as the block's custom properties: a preset by
	 * its slug, or a custom value.
	 *
	 * @since 4.18.0
	 *
	 * @param array $attributes Block attributes.
	 * @return array<string, string>
	 */
	private static function block_tokens( array $attributes ): array {
		$style  = (array) ( $attributes['style'] ?? array() );
		$preset = static fn( string $kind, $slug ): string => is_string( $slug ) && '' !== $slug ? 'var(--wp--preset--' . $kind . '--' . sanitize_key( $slug ) . ')' : '';
		$tokens = array(
			'--riff-app-bg'     => $preset( 'color', $attributes['backgroundColor'] ?? '' ),
			'--riff-app-ink'    => $preset( 'color', $attributes['textColor'] ?? '' ),
			'--riff-app-accent' => '',
			'--riff-app-font'   => $preset( 'font-family', $attributes['fontFamily'] ?? '' ),
		);
		$custom = array(
			'--riff-app-bg'     => $style['color']['background'] ?? '',
			'--riff-app-ink'    => $style['color']['text'] ?? '',
			'--riff-app-accent' => $style['elements']['link']['color']['text'] ?? '',
		);
		foreach ( $custom as $token => $value ) {
			if ( '' === $tokens[ $token ] && is_string( $value ) && '' !== $value ) {
				// A preset picked in the editor is stored as var:preset|color|slug.
				$tokens[ $token ] = preg_match( '/^var:preset\|([a-z0-9-]+)\|([a-z0-9-]+)$/', $value, $m ) ? $preset( $m[1], $m[2] ) : $value;
			}
		}
		// A font chosen for this block is its headings' font too.
		if ( '' !== $tokens['--riff-app-font'] ) {
			$tokens['--riff-app-heading-font'] = 'var(--riff-app-font)';
		}
		return array_filter( $tokens );
	}

	/**
	 * The block's custom properties as a style attribute's declarations, kept to what WordPress
	 * lets through a block's style attribute, so the block and the shortcode agree.
	 *
	 * @since 4.14.0
	 *
	 * @param array|null $tokens Custom property values keyed by name; the theme's when null.
	 * @return string CSS declarations, or an empty string.
	 */
	public static function theme_style( ?array $tokens = null ): string {
		$css = '';
		foreach ( $tokens ?? self::theme_tokens() as $token => $value ) {
			$css .= $token . ':' . $value . ';';
		}
		return '' === $css ? '' : (string) safecss_filter_attr( $css );
	}

	/**
	 * The post the address opens, when there is one that can be played.
	 *
	 * @since 4.0.0
	 * @return WP_Post|null
	 */
	private static function requested(): ?WP_Post {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which post to show; nothing changes.
		$raw = isset( $_GET[ self::QUERY ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::QUERY ] ) ) : '';
		if ( '' === $raw ) {
			return null;
		}
		// An ID, or a post's slug: ?riff=compositions reads as well as ?riff=12, for links written by hand.
		$post = ctype_digit( $raw ) ? get_post( (int) $raw ) : get_page_by_path( $raw, OBJECT, 'post' );
		if ( ! $post instanceof WP_Post || ! Protect::post_readable( $post ) ) {
			return null;
		}
		return $post;
	}

	/**
	 * How many pages of the library the address asks for: 1 unless ?riff_page says more. Or, with
	 * ?riff_from, the page to start at.
	 *
	 * @param string $arg Which argument to read.
	 * @return int
	 */
	private static function requested_pages( string $arg = self::PAGE_QUERY ): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which page to show; nothing changes.
		$raw = isset( $_GET[ $arg ] ) ? sanitize_text_field( wp_unslash( $_GET[ $arg ] ) ) : '';
		return ctype_digit( $raw ) ? max( 1, (int) $raw ) : 1;
	}

	/**
	 * The address of a post inside the app.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $page    The app page's address.
	 * @return string
	 */
	public static function link( int $post_id, string $page ): string {
		return add_query_arg( self::QUERY, $post_id, $page );
	}

	/**
	 * Posts: a grid of the posts with tracks, through the page the address asks for.
	 *
	 * Each page is the same page the REST route returns, one after another, so the grid holds what
	 * pressing Load more that many times would have. Load more is a link to one page further, and
	 * works without the script; with it, app.js adds the next page in place.
	 *
	 * @since 4.0.0
	 * @since 4.13.0 Shows the pages ?riff_page asks for, with a Load more link while there are more.
	 * @since 4.18.0 Its own view, at riff_view=posts, now that Home opens the page.
	 *
	 * @param string $page The app page's address.
	 * @return string
	 */
	public static function posts_view( string $page ): string {
		$query = Library::query();
		if ( ! $query->posts ) {
			// How to fill it is for someone who can write a post.
			return Ui::empty_note( current_user_can( 'edit_posts' ) ? __( 'Nothing to play yet. Add an audio or video block to a post.', 'riff' ) : __( 'Nothing to play yet.', 'riff' ) );
		}
		$pages = max( 1, (int) $query->max_num_pages );
		$upto  = min( self::requested_pages(), $pages );
		// Load more asks only for the page it adds, so each press costs one page, not all of them.
		$from  = min( self::requested_pages( self::FROM_QUERY ), $upto );
		$cards = '';
		for ( $n = $from; $n <= $upto; $n++ ) {
			$posts = 1 === $n ? $query->posts : Library::query( array( 'paged' => $n ) )->posts;
			Library::prime( $posts );
			foreach ( array_values( $posts ) as $i => $post ) {
				$cards .= self::card( Library::item( $post ), $page, 0 === $i && $n > 1 ? $n : 0 );
			}
		}
		$more = '';
		if ( $upto < $pages ) {
			$more = sprintf(
				'<p class="riff-app-more"><a class="riff-pill" href="%s" data-riff-app-action="more">%s</a></p>',
				esc_url(
					add_query_arg(
						array(
							Browse::VIEW     => 'posts',
							self::PAGE_QUERY => $upto + 1,
						),
						$page
					) . '#riff-page-' . ( $upto + 1 )
				),
				esc_html__( 'Load more', 'riff' )
			);
		}
		return sprintf(
			'%s<div class="riff-grid" data-riff-page="%d" data-riff-pages="%d">%s</div>%s',
			Ui::title( __( 'Posts', 'riff' ) ),
			$upto,
			$pages,
			$cards,
			$more
		);
	}

	/**
	 * The newest posts with tracks as cards, for a row on Home.
	 *
	 * @since 4.18.0
	 *
	 * @param string $page The app page's address.
	 * @return string Cards, or empty when there are none.
	 */
	public static function post_cards( string $page ): string {
		$cards = '';
		$posts = Library::query(
			array(
				'posts_per_page' => 12,
				'no_found_rows'  => true,
			)
		)->posts;
		Library::prime( $posts );
		foreach ( $posts as $post ) {
			$cards .= self::card( Library::item( $post ), $page );
		}
		return $cards;
	}

	/**
	 * One post in the grid.
	 *
	 * @param array  $item  Library item.
	 * @param string $page  The app page's address.
	 * @param int    $first The page this card starts, for Load more's link to land on, or 0.
	 * @return string
	 */
	private static function card( array $item, string $page, int $first = 0 ): string {
		return Ui::card(
			array(
				'title'   => (string) $item['title'],
				'href'    => self::link( (int) $item['id'], $page ),
				'sub'     => (string) ( $item['meta'] ?? self::meta( $item ) ),
				'art'     => (array) $item['art'],
				'id'      => $first ? 'riff-page-' . $first : '',
				'data'    => array( 'post' => (int) $item['id'] ),
				'play'    => array(
					'action' => 'play-card',
					'data'   => array( 'post' => (int) $item['id'] ),
					/* translators: %s: track or post title. */
					'label'  => sprintf( __( 'Play %s', 'riff' ), $item['title'] ),
				),
				'private' => Library::is_private( (int) $item['id'] ),
			)
		);
	}

	/**
	 * Writes the byline into a library item, so the app and the REST route carry it with the
	 * language's own plural forms instead of composing it in JavaScript.
	 *
	 * @since 4.0.0
	 *
	 * @param array    $item Library item.
	 * @param \WP_Post $post Its post.
	 * @return array
	 */
	public static function item_meta( $item, $post ) {
		unset( $post );
		if ( is_array( $item ) ) {
			$item['meta'] = self::meta( $item );
		}
		return $item;
	}

	/**
	 * A post opened: its title and byline beside Play and Shuffle, then its tracks, the blocks
	 * rendered as the post renders them.
	 *
	 * @param WP_Post $post Post.
	 * @param string  $page The app page's address.
	 * @return string
	 */
	private static function post_view( WP_Post $post, string $page ): string {
		$detail = Library::post( $post );
		if ( ! $detail['tracks'] ) {
			return Home_View::view( $page );
		}
		return self::header( $detail['title'], self::meta( $detail ), '', (array) $detail['art'], Art::tint( (array) $detail['art'] ), post: $post->ID ) . sprintf(
			'<div class="riff-album-tracks" data-riff-numbered data-riff-tracks="%s">%s</div>',
			esc_attr( wp_json_encode( $detail['tracks'] ) ),
			$detail['html']
		);
	}

	/**
	 * The header of a list of tracks: the cover, what it is, its title and details, and Play and
	 * Shuffle under them, as the music apps draw an album.
	 *
	 * @since 4.17.0
	 * @since 4.20.0 A heart beside Play and Shuffle, for an album or artist; a playlist's mosaic,
	 *               and more buttons beside Play and Shuffle.
	 * @since 4.28.0 A cover drawn in markup.
	 * @since 5.7.0 The line under it may be parts, each text or `[ text, address ]` for a link.
	 * @since 5.8.0 The cover may be its sizes, which the browser picks from.
	 * @since 6.8.0 The $post parameter: a post marked private, for those who may see it.
	 *
	 * @param string       $title Title.
	 * @param string|array $meta  The line under it, or its parts.
	 * @param string       $kind  What it is, above the title ("Album"), or empty.
	 * @param string|array $art   The cover: its sizes, as a track's art list, or one address, or empty for none.
	 * @param string       $tint  A hex colour from the cover to tint the header with, or empty.
	 * @param bool         $round Whether the picture is round, as an artist's is.
	 * @param string       $like  What the heart likes, "album" or "artist", or empty for no heart.
	 * @param int          $id     The album's or artist's term ID, for the heart.
	 * @param array        $covers Up to four covers for a playlist's mosaic, when there is no art.
	 * @param string       $extra  More buttons after Play and Shuffle, or empty.
	 * @param string       $drawn  A cover drawn in markup, when there is no picture: Liked songs' heart.
	 * @param int          $post   The post the list is, to mark it when Library::is_private() says so, or 0.
	 * @return string
	 */
	public static function header( string $title, string|array $meta, string $kind = '', string|array $art = '', string $tint = '', bool $round = false, string $like = '', int $id = 0, array $covers = array(), string $extra = '', string $drawn = '', int $post = 0 ): string {
		$tint  = (string) sanitize_hex_color( $tint );
		$heart = in_array( $like, array( 'album', 'artist' ), true ) && $id > 0 ? Ui::heart( $like, $id, $title ) : '';
		// The cover at the head of a list is what its page is painted around, so it loads first.
		Ui::lead( 1 );
		$cover = array() !== $art && '' !== $art ? Ui::image( is_array( $art ) ? $art : array( array( 'src' => $art ) ), Ui::HEADER_SIZES ) : '';
		Ui::lead( 0 );
		$cover = '' !== $cover ? $cover : ( '' !== $drawn ? $drawn : Ui::mosaic( $covers ) );
		// A longer title is set smaller, so it keeps to a line or two beside the cover.
		$length = mb_strlen( $title );
		$length = $length > 40 ? ' riff-album-longer' : ( $length > 20 ? ' riff-album-long' : '' );
		return sprintf(
			'<header class="riff-album%1$s"%6$s>%2$s<div class="riff-album-text">%3$s<h2 class="riff-album-title" tabindex="-1">%4$s</h2><p class="riff-album-meta">%5$s</p>%7$s</div></header>',
			( '' !== $cover ? ' riff-album-has-cover' : '' ) . ( '' !== $tint ? ' riff-album-tinted' : '' ) . ( $round ? ' riff-album-round' : '' ) . $length,
			'' !== $cover ? '<span class="riff-album-cover">' . $cover . '</span>' : '',
			'' !== $kind ? '<p class="riff-album-kind">' . esc_html( $kind ) . '</p>' : '',
			esc_html( $title ),
			self::private_line( $post ) . self::meta_line( $meta ),
			'' !== $tint ? ' style="--riff-album-tint:' . esc_attr( $tint ) . '"' : '',
			Ui::actions( $heart . $extra )
		);
	}

	/**
	 * A private post's mark at the head of its line, shown in words, and for someone who may edit
	 * the post a link to the editor, where its visibility is changed. Empty for any other post.
	 *
	 * @param int $post Post ID, or 0.
	 * @return string
	 */
	private static function private_line( int $post ): string {
		if ( ! Library::is_private( $post ) ) {
			return '';
		}
		$edit = current_user_can( 'edit_post', $post ) ? (string) get_edit_post_link( $post, 'raw' ) : '';
		return Ui::private_mark( true, $edit ) . ' · ';
	}

	/**
	 * A header's line, escaped: its parts between dots, each text or a link.
	 *
	 * @param string|array $meta The line, or its parts, each text or `[ text, address ]`.
	 * @return string
	 */
	private static function meta_line( string|array $meta ): string {
		$parts = array();
		foreach ( (array) $meta as $part ) {
			$parts[] = is_array( $part )
				? '<a href="' . esc_url( (string) $part[1] ) . '">' . esc_html( (string) $part[0] ) . '</a>'
				: esc_html( (string) $part );
		}
		return implode( ' · ', $parts );
	}

	/**
	 * "Artist · 10 tracks · 7 min", with the parts that are known.
	 *
	 * @param array $item Library item.
	 * @return string
	 */
	public static function meta( array $item ): string {
		$parts = array();
		if ( ! empty( $item['artist'] ) ) {
			$parts[] = $item['artist'];
		}
		/* translators: %s: number of tracks. */
		$parts[] = sprintf( _n( '%s track', '%s tracks', (int) $item['count'], 'riff' ), number_format_i18n( (int) $item['count'] ) );
		$minutes = (int) round( (float) $item['duration'] / 60 );
		if ( $minutes ) {
			/* translators: %s: number of minutes. */
			$parts[] = sprintf( _n( '%s min', '%s min', $minutes, 'riff' ), number_format_i18n( $minutes ) );
		}
		return implode( ' · ', $parts );
	}
}
