<?php
/**
 * WP-CLI commands.
 *
 * @since 4.16.0
 * @package Riff
 */

namespace Riff;

use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * Manages Riff's music from the command line.
 */
final class Cli {

	/**
	 * Registers `wp riff` when WP-CLI is running.
	 *
	 * @since 4.16.0
	 */
	public static function register(): void {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WP_CLI::add_command( 'riff', self::class );
			WP_CLI::add_command( 'riff protected', Protected_Cli::class );
		}
	}

	/**
	 * Files every audio file in the Media Library under its album and artist, from its tags.
	 *
	 * New uploads and imports are filed as they arrive, and a library from before Riff 4.16.0 is
	 * filed in the background; this does the whole library now.
	 *
	 * ## EXAMPLES
	 *
	 *     wp riff catalog
	 *
	 * @since 4.16.0
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function catalog( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$total = 0;
		// From the start, so a file whose filing was lost is found wherever it is.
		delete_option( Catalog::BACKFILL );
		delete_option( Catalog::BACKFILL_FROM );
		do {
			$total += Catalog::backfill();
		} while ( ! Catalog::filed() );
		WP_CLI::success( sprintf( 'Filed %d audio files under their albums and artists.', $total ) );
	}

	/**
	 * Makes streaming versions of songs with ffmpeg.
	 *
	 * Each version is an MP3 without the file's tags, uploaded to the Media Library beside its song
	 * and set as the song's Streaming version: the player streams it, and the song stays the file
	 * it is. It goes to the same post as the song, so the same listeners may play it, and is
	 * protected when the song is. Without IDs, every song that has no version yet and is lossless,
	 * or of a bit rate well above the version's. Needs ffmpeg on the server.
	 *
	 * ## OPTIONS
	 *
	 * [<id>...]
	 * : Audio files to make versions of, by attachment ID, whatever their bit rate.
	 *
	 * [--bitrate=<kbps>]
	 * : The versions' bit rate.
	 * ---
	 * default: 192
	 * ---
	 *
	 * [--dry-run]
	 * : List the songs that would get a version, without making any.
	 *
	 * ## EXAMPLES
	 *
	 *     wp riff transcode
	 *     wp riff transcode 412 418 --bitrate=256
	 *
	 * @since 5.8.0
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function transcode( array $args, array $assoc_args ): void {
		$dry  = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$kbps = max( 32, (int) ( $assoc_args['bitrate'] ?? Transcode::BITRATE ) );
		if ( ! $dry && '' === Transcode::ffmpeg() ) {
			WP_CLI::error( 'ffmpeg is not installed on this server, so no streaming version can be made here.' );
		}
		$ids = array_map( 'intval', $args );
		if ( ! $ids ) {
			$ids = array_filter(
				self::songs(),
				static fn( int $id ): bool => ! Media::stream( $id ) && ! Media::streamed( $id ) && Transcode::worth( $id, $kbps )
			);
		}
		$made   = 0;
		$failed = 0;
		foreach ( $ids as $id ) {
			$title = get_the_title( $id );
			if ( $dry ) {
				WP_CLI::log( sprintf( '%d: %s', $id, $title ) );
				continue;
			}
			$version = Transcode::make( $id, $kbps );
			if ( is_wp_error( $version ) ) {
				++$failed;
				WP_CLI::warning( sprintf( '%d: %s: %s', $id, $title, $version->get_error_message() ) );
				continue;
			}
			++$made;
			WP_CLI::log( sprintf( '%d: %s -> %d', $id, $title, $version ) );
		}
		if ( $dry ) {
			WP_CLI::success( sprintf( 'Dry run. %d songs would get a streaming version.', count( $ids ) ) );
		} elseif ( $failed ) {
			WP_CLI::warning( sprintf( '%d streaming versions made, %d failed.', $made, $failed ) );
		} else {
			WP_CLI::success( sprintf( '%d streaming versions made.', $made ) );
		}
	}

	/**
	 * Measures songs' levels with ffmpeg: their loudness over time, which a drawn cover puts in its
	 * groove. Kept in each file's metadata, as the demo albums' are. Without IDs, every song not
	 * measured yet. Needs ffmpeg on the server.
	 *
	 * ## OPTIONS
	 *
	 * [<id>...]
	 * : Audio files to measure, by attachment ID, measured or not.
	 *
	 * [--force]
	 * : Measure every song again, not only those without levels.
	 *
	 * ## EXAMPLES
	 *
	 *     wp riff levels
	 *     wp riff levels 412 418
	 *
	 * @since 5.8.0
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function levels( array $args, array $assoc_args ): void {
		if ( '' === Transcode::ffmpeg() ) {
			WP_CLI::error( 'ffmpeg is not installed on this server, so no levels can be measured here.' );
		}
		$force = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'force', false );
		$ids   = array_map( 'intval', $args );
		if ( ! $ids ) {
			$ids = array_filter(
				self::songs(),
				static function ( int $id ) use ( $force ): bool {
					$meta = wp_get_attachment_metadata( $id );
					return ! Media::streamed( $id ) && ( $force || empty( $meta['riff_levels'] ) );
				}
			);
		}
		$done   = 0;
		$failed = 0;
		foreach ( $ids as $id ) {
			$levels = Transcode::measure( $id );
			if ( is_wp_error( $levels ) ) {
				++$failed;
				WP_CLI::warning( sprintf( '%d: %s: %s', $id, get_the_title( $id ), $levels->get_error_message() ) );
				continue;
			}
			++$done;
		}
		if ( $failed ) {
			WP_CLI::warning( sprintf( '%d songs measured, %d failed.', $done, $failed ) );
		} else {
			WP_CLI::success( sprintf( '%d songs measured.', $done ) );
		}
	}

	/**
	 * Every audio file in the Media Library, oldest first, by ID alone.
	 *
	 * @return int[]
	 */
	private static function songs(): array {
		return array_map(
			'intval',
			get_posts(
				array(
					'post_type'              => 'attachment',
					'post_mime_type'         => 'audio',
					'post_status'            => 'inherit',
					'posts_per_page'         => -1,
					'fields'                 => 'ids',
					'orderby'                => 'ID',
					'order'                  => 'ASC',
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			)
		);
	}

	/**
	 * Imports recordings that a public archive publishes for reuse, with their credit.
	 *
	 * Rights are per item, so each item's own rights statement is read, and only what it says is
	 * free to reuse is imported: the public domain mark, CC0, CC BY and CC BY-SA, and from the
	 * Library of Congress, which says it in words, what its statement says it knows of no U.S.
	 * copyright in. Everything else is skipped, and said. Each item becomes an album, imported as `wp riff import` imports a
	 * folder, and each track keeps its source, licence and credit in its caption and description,
	 * which the About panel shows. Running it again skips what it has already imported.
	 *
	 * ## OPTIONS
	 *
	 * <archive>
	 * : The archive.
	 * ---
	 * options:
	 *   - loc
	 *   - europeana
	 * ---
	 *
	 * [<what>]
	 * : For loc, a collection, by its address or its name in it, or an item by its address; the
	 * Edison companies' sound recordings when none is given. For europeana, what to search for.
	 *
	 * [--limit=<n>]
	 * : How many items to look at.
	 * ---
	 * default: 25
	 * ---
	 *
	 * [--key=<key>]
	 * : Europeana's API key, which it gives anyone who asks for one.
	 *
	 * [--status=<status>]
	 * : Status for new album posts.
	 * ---
	 * default: publish
	 * options:
	 *   - publish
	 *   - draft
	 *   - private
	 * ---
	 *
	 * [--dry-run]
	 * : List the recordings it would download and the items it would skip, without downloading.
	 *
	 * ## EXAMPLES
	 *
	 *     wp riff archive loc
	 *     wp riff archive loc https://www.loc.gov/item/00694028/
	 *     wp riff archive europeana "gramophone" --key=yourkey --limit=10
	 *
	 * @since 6.5.0
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function archive( array $args, array $assoc_args ): void {
		$dry    = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$result = Archives::import(
			(string) $args[0],
			(string) ( $args[1] ?? '' ),
			array(
				'limit'   => (int) ( $assoc_args['limit'] ?? Archives::LIMIT ),
				'key'     => (string) ( $assoc_args['key'] ?? '' ),
				'status'  => (string) ( $assoc_args['status'] ?? 'publish' ),
				'dry_run' => $dry,
			)
		);
		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
		}
		$tracks = 0;
		$failed = 0;
		foreach ( $result['albums'] as $album ) {
			$tracks += count( $album['imported'] );
			$failed += count( $album['failed'] );
			$where   = $album['post'] ? get_permalink( $album['post'] ) : $album['folder'];
			WP_CLI::log( sprintf( '%s: %d imported, %d skipped, %d failed', $where, count( $album['imported'] ), count( $album['skipped'] ), count( $album['failed'] ) ) );
			foreach ( $album['failed'] as $file => $message ) {
				WP_CLI::warning( "$file: $message" );
			}
		}
		foreach ( $result['refused'] as $url => $why ) {
			WP_CLI::log( "Skipped $url: $why" );
		}
		$summary = sprintf( '%d items: %d tracks imported, %d failed; %d items skipped.', count( $result['albums'] ), $tracks, $failed, count( $result['refused'] ) );
		if ( $dry ) {
			WP_CLI::success( 'Dry run. ' . $summary );
		} elseif ( $failed ) {
			WP_CLI::warning( $summary );
		} else {
			WP_CLI::success( $summary );
		}
	}

	/**
	 * Imports a folder of music, or a zip of one, into the Media Library.
	 *
	 * Each folder that holds audio, the one given and any inside it, becomes an album: its files are
	 * added to the Media Library the way an upload is, so WordPress reads their tags and artwork,
	 * and a post with one audio block per track publishes them. A cover, folder or front image in
	 * the folder becomes the album's artwork, and a video named like a track becomes its video
	 * version. Running it again skips what it has already imported and adds new tracks to the
	 * album's post. A zip is unpacked into a temporary folder, imported the same way, and removed.
	 *
	 * A zip is imported privately unless --no-private is given, as a zip is how a store's download
	 * arrives, bought for its buyer's own listening: each track it adds is Protected, so only those who may
	 * read its post can load the file, and each album's post is private. An artist importing their
	 * own releases gives --no-private. A folder is imported publicly unless --private is given.
	 *
	 * ## OPTIONS
	 *
	 * <path>
	 * : The folder on the server to import, or a zip of it.
	 *
	 * [--[no-]private]
	 * : Protect each track and keep new album posts private. On for a zip, off for a folder.
	 *
	 * [--status=<status>]
	 * : Status for new album posts. Private when the import is, otherwise publish.
	 * ---
	 * options:
	 *   - publish
	 *   - draft
	 *   - private
	 * ---
	 *
	 * [--dry-run]
	 * : List what would be imported and skipped, without importing anything.
	 *
	 * ## EXAMPLES
	 *
	 *     wp riff import ~/Music/Floating\ Points
	 *     wp riff import /srv/music --status=draft
	 *     wp riff import ~/Downloads/album.zip
	 *     wp riff import ~/Releases/our-first-album.zip --no-private
	 *
	 * @since 4.16.0
	 * @since 5.9.0 Takes a zip.
	 * @since 6.5.0 --private, on by default for a zip.
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function import( array $args, array $assoc_args ): void {
		$dry     = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$path    = (string) $args[0];
		$private = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'private', is_file( $path ) );
		$options = array(
			'private' => $private,
			'status'  => (string) ( $assoc_args['status'] ?? ( $private ? 'private' : 'publish' ) ),
			'dry_run' => $dry,
		);
		$result  = is_file( $path ) ? Import::zip( $path, $options ) : Import::folder( $path, $options );
		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
		}
		$counts = array(
			'imported' => 0,
			'skipped'  => 0,
			'failed'   => 0,
		);
		foreach ( $result['albums'] as $album ) {
			$counts['imported'] += count( $album['imported'] );
			$counts['skipped']  += count( $album['skipped'] );
			$counts['failed']   += count( $album['failed'] );
			$where               = $album['post'] ? get_permalink( $album['post'] ) : $album['folder'];
			WP_CLI::log( sprintf( '%s: %d imported, %d skipped, %d failed', $where, count( $album['imported'] ), count( $album['skipped'] ), count( $album['failed'] ) ) );
			foreach ( $album['failed'] as $file => $message ) {
				WP_CLI::warning( "$file: $message" );
			}
		}
		if ( ! $result['albums'] ) {
			WP_CLI::warning( is_file( $path ) ? 'No audio found in that zip.' : 'No audio found in that folder.' );
			return;
		}
		$summary = sprintf( '%d albums: %d tracks imported, %d skipped, %d failed.', count( $result['albums'] ), $counts['imported'], $counts['skipped'], $counts['failed'] );
		if ( $dry ) {
			WP_CLI::success( 'Dry run. ' . $summary );
		} elseif ( $counts['failed'] ) {
			WP_CLI::warning( $summary );
		} else {
			WP_CLI::success( $summary );
		}
	}

	/**
	 * Deletes the zips earlier versions of Riff left in the Media Library after importing them.
	 *
	 * Before 6.15.1, a zip uploaded to the Media Library was attached to its album's post once it
	 * was imported, and kept. Core serves an upload's file at a public address, so each one holds
	 * the tracks its import Protected, unprotected. This finds each zip attached to the album post
	 * its own import made, and deletes its attachment and file; and each zip that did not become an
	 * album and still has its file, and deletes the file, keeping the attachment, private, with why.
	 * A zip attached to a post as a download, or attached to no post by an earlier version, is left
	 * as it is. A zip kept with the riff_import_keep_zip filter is one of these, and is deleted too.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : List the zips, without deleting them.
	 *
	 * ## EXAMPLES
	 *
	 *     wp riff clean-zips --dry-run
	 *     wp riff clean-zips
	 *
	 * @since 6.15.1
	 * @subcommand clean-zips
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function clean_zips( array $args, array $assoc_args ): void {
		$dry     = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$deleted = 0;
		foreach ( Import::left_behind() as $id ) {
			$name = wp_basename( (string) get_attached_file( $id ) );
			if ( $dry ) {
				WP_CLI::log( sprintf( 'Would delete %s (attachment %d)', $name, $id ) );
				++$deleted;
			} elseif ( wp_delete_attachment( $id, true ) ) {
				WP_CLI::log( sprintf( 'Deleted %s (attachment %d)', $name, $id ) );
				++$deleted;
			} else {
				WP_CLI::warning( sprintf( 'Could not delete %s (attachment %d)', $name, $id ) );
			}
		}
		foreach ( Import::failed_with_files() as $id ) {
			$name = wp_basename( (string) get_attached_file( $id ) );
			if ( $dry ) {
				WP_CLI::log( sprintf( 'Would delete the file of %s, which did not import (attachment %d)', $name, $id ) );
				++$deleted;
			} elseif ( Import::drop_file( $id ) ) {
				WP_CLI::log( sprintf( 'Deleted the file of %s, which did not import (attachment %d)', $name, $id ) );
				++$deleted;
			} else {
				WP_CLI::warning( sprintf( 'Could not delete the file of %s (attachment %d)', $name, $id ) );
			}
		}
		WP_CLI::success( $dry ? sprintf( 'Dry run. %d imported zips to delete.', $deleted ) : sprintf( '%d imported zips deleted.', $deleted ) );
	}
}
