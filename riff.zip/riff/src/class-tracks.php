<?php
/**
 * Turns attachments and media blocks into the track data the player reads.
 *
 * @since 4.0.0
 * @package Riff
 */

namespace Riff;

use WP_HTML_Tag_Processor;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * Track data.
 *
 * A track is an array with these keys, the same shape the player keeps in its queue:
 * id (string), src, type ('audio' or 'video'), title, artist, album, year (0 when unknown), disc (the disc of a set the
 * file's tags put it on, 0 when they don't say), duration (seconds, 0 when unknown), lang (the title's language, or empty), art (list of { src, sizes, alt }), captions (list of
 * { src, label, srclang, kind } for a video), video ({ src, poster, captions } or null), and post ({ title, url }).
 */
final class Tracks {

	/**
	 * Image sizes offered as artwork, smallest first. The lock screen picks the size it wants, and
	 * so does a cover's srcset: medium_large is what a card on a phone's sharp screen asks for,
	 * between medium, too soft there, and large.
	 */
	private const ART_SIZES = array( 'thumbnail', 'medium', 'medium_large', 'large' );

	/**
	 * Tracks kept as IDs, as the current user may see them now: each as it plays from its post,
	 * which names where it plays from and lends its art, while the user can still read that post.
	 * A Listen page is not where a track plays from, though older plays may name one. The result
	 * keeps the keys of `$items`, with null for a track the user can't see.
	 *
	 * @since 5.6.0
	 * @since 5.7.0 A Listen page named as where a track played from is left out.
	 *
	 * @param array[] $items Each `{ id, post }`: the audio attachment, and the post it played from.
	 * @return array<int, array|null> Tracks without their level envelope, as the player keeps them.
	 */
	public static function readable( array $items ): array {
		$ids = array_values( array_unique( array_filter( array_map( static fn( $item ) => (int) ( $item['id'] ?? 0 ), $items ) ) ) );
		if ( ! $ids ) {
			return array_map( static fn() => null, $items );
		}
		// Through the tracks route, so a track the user may not play is left out as it is there.
		$request = new WP_REST_Request( 'GET', '/' . Library::REST . '/tracks' );
		$request->set_query_params(
			array(
				'include'  => $ids,
				'orderby'  => 'include',
				'per_page' => min( 100, count( $ids ) ),
			)
		);
		$response = rest_do_request( $request );
		$found    = $response->is_error() ? array() : array_column( (array) ( $response->get_data()['items'] ?? array() ), null, 'id' );
		// The posts each was played from, in one go rather than one at a time below.
		self::prime( $ids, array_map( static fn( $item ) => (int) ( $item['post'] ?? 0 ), $items ) );
		$tracks = array();
		foreach ( $items as $key => $item ) {
			$track = $found[ (string) ( $item['id'] ?? '' ) ] ?? null;
			$post  = get_post( (int) ( $item['post'] ?? 0 ) );
			if ( $track && $post && ! Listen\App::holds_app( $post ) && ( is_post_publicly_viewable( $post ) || current_user_can( 'read_post', $post->ID ) ) && ! post_password_required( $post ) ) {
				$track = self::from_attachment( (int) $item['id'], $post->ID ) ?? $track;
			}
			if ( $track ) {
				unset( $track['levels'] );
			}
			$tracks[ $key ] = $track;
		}
		return $tracks;
	}

	/**
	 * Loads what building these tracks reads, in a few queries rather than a few for each track:
	 * the files and the posts they play from, then the posts the files were uploaded to and every
	 * file those name (artwork, a video version, captions), then what those name in turn, a video's
	 * poster and its captions. Each with its meta.
	 *
	 * @since 5.7.0
	 *
	 * @param int[] $attachments Audio or video attachment IDs.
	 * @param int[] $posts       The posts they play from, if not the posts they were uploaded to.
	 */
	public static function prime( array $attachments, array $posts = array() ): void {
		$seen = array();
		$ids  = array_merge( $attachments, $posts );
		for ( $depth = 0; $depth < 3; $depth++ ) {
			$ids = array_diff( array_unique( array_filter( array_map( 'intval', $ids ) ) ), $seen );
			if ( ! $ids ) {
				return;
			}
			self::load( $ids );
			$seen = array_merge( $seen, $ids );
			$next = array();
			foreach ( $ids as $id ) {
				if ( 'attachment' === get_post_type( $id ) ) {
					$next[] = get_post_field( 'post_parent', $id );
				}
				$next[] = get_post_meta( $id, '_thumbnail_id', true );
				$next[] = get_post_meta( $id, Media::VIDEO_META, true );
				$next[] = get_post_meta( $id, Media::CAPTIONS_META, true );
			}
			$ids = $next;
		}
	}

	/**
	 * Loads posts of any type or status, and their meta, into the cache: one query for the posts
	 * not already there, and one for the meta not already there.
	 *
	 * @param int[] $ids Post IDs.
	 */
	private static function load( array $ids ): void {
		$missing = array_values( array_filter( $ids, static fn( $id ) => false === wp_cache_get( $id, 'posts' ) ) );
		if ( $missing ) {
			get_posts(
				array(
					'post__in'               => $missing,
					'post_type'              => get_post_types(),
					'post_status'            => get_post_stati(),
					'numberposts'            => count( $missing ),
					'orderby'                => 'none',
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			);
		}
		update_meta_cache( 'post', $ids );
	}

	/**
	 * Changes some keys of an attachment's metadata and leaves the rest as they are now, read again
	 * just before the write rather than whenever this request first read them, so a key another
	 * writer saved meanwhile (an import's tags, a measured envelope, the words) is kept. Saved
	 * through core, so its filter, and the catalog with it, still see the change.
	 *
	 * @since 6.17.0
	 *
	 * @param int   $id      Attachment ID.
	 * @param array $changes Keys to set; one set to null is taken away.
	 * @return bool Whether it was saved.
	 */
	public static function update_metadata( int $id, array $changes ): bool {
		wp_cache_delete( $id, 'post_meta' );
		$meta = wp_get_attachment_metadata( $id, true );
		$meta = is_array( $meta ) ? $meta : array();
		foreach ( $changes as $key => $value ) {
			if ( null === $value ) {
				unset( $meta[ $key ] );
			} else {
				$meta[ $key ] = $value;
			}
		}
		return (bool) wp_update_attachment_metadata( $id, $meta );
	}

	/**
	 * Builds a track from an audio or video attachment.
	 *
	 * @since 4.0.0
	 * @param int $attachment_id Attachment ID.
	 * @param int $post_id       The post the track appears in, for artwork fallback and "Playing from".
	 * @return array|null Null when the attachment is not audio or video.
	 */
	public static function from_attachment( int $attachment_id, int $post_id = 0 ): ?array {
		$mime = (string) get_post_mime_type( $attachment_id );
		$type = strtok( $mime, '/' );
		if ( 'audio' !== $type && 'video' !== $type ) {
			return null;
		}
		$src = wp_get_attachment_url( $attachment_id );
		if ( ! $src ) {
			return null;
		}
		$meta = wp_get_attachment_metadata( $attachment_id );
		$meta = is_array( $meta ) ? $meta : array();

		$art = self::art( (int) get_post_thumbnail_id( $attachment_id ) );
		if ( ! $art ) {
			$art = self::post_art( $post_id );
		}

		$video = null;
		// What plays, and so what its quality says: the file, or a smaller version of it to stream
		// when the site has one, while the track stays the file, its tags, length and levels.
		$file = $meta;
		if ( 'audio' === $type ) {
			$video_id = (int) get_post_meta( $attachment_id, Media::VIDEO_META, true );
			$video    = $video_id ? self::video( $video_id, $art ) : null;
			$stream   = Media::stream( $attachment_id );
			$version  = $stream ? wp_get_attachment_url( $stream ) : false;
			if ( $version ) {
				$src  = $version;
				$file = wp_get_attachment_metadata( $stream );
				$file = is_array( $file ) ? $file : array();
			}
		}

		return self::filter(
			array(
				'id'        => (string) $attachment_id,
				'src'       => $src,
				'type'      => $type,
				'title'     => self::title( $attachment_id, $meta ),
				'artist'    => isset( $meta['artist'] ) ? (string) $meta['artist'] : '',
				'album'     => isset( $meta['album'] ) ? (string) $meta['album'] : '',
				'year'      => isset( $meta['year'] ) && is_numeric( $meta['year'] ) ? (int) $meta['year'] : 0,
				// The disc of a set, from the file's tags: an MP3's part-of-a-set frame, which WordPress
				// keeps on upload as part_of_a_set, and a FLAC, Ogg or M4A file's disc number, which
				// Media::tags() keeps under the same name. Written as a number or as "1/2", disc 1 of 2.
				'disc'      => self::disc( $meta['part_of_a_set'] ?? '' ),
				'duration'  => isset( $meta['length'] ) ? (float) $meta['length'] : 0,
				// The language the file's tags name, which Media::language() keeps on upload, so a
				// title in another script can say what it is.
				'lang'      => Media::language_code( (string) ( $meta['language'] ?? '' ) ),
				// What WordPress read from the file on upload: the container, the bit rate, whether it is
				// lossless, and for a lossless file its bit depth and sample rate. The player shows them
				// on every track, the way the streaming services do.
				'format'    => strtolower( (string) ( $file['dataformat'] ?? $file['fileformat'] ?? '' ) ),
				'bitrate'   => isset( $file['bitrate'] ) ? (int) round( (float) $file['bitrate'] / 1000 ) : 0,
				'lossless'  => ! empty( $file['lossless'] ),
				'bits'      => (int) ( $file['bits_per_sample'] ?? 0 ),
				'rate'      => (int) ( $file['sample_rate'] ?? 0 ),
				// Level data, when something measured it on upload and stored it as riff_levels.
				'levels'    => isset( $meta['riff_levels'] ) && is_string( $meta['riff_levels'] ) ? $meta['riff_levels'] : '',
				'art'       => $art,
				'captions'  => 'video' === $type ? self::captions( $attachment_id ) : array(),
				'video'     => $video,
				'post'      => self::post( $post_id ),
				// What the artist chose: the rights and licence, null while nothing is set, and
				// whether this listener may download the file.
				'rights'    => Rights::for_track( $attachment_id ),
				'downloads' => Rights::may_download( $attachment_id, get_current_user_id() ),
				'links'     => Rights::links( $attachment_id ),
			),
			$attachment_id,
			$post_id
		);
	}

	/**
	 * A video's captions, from the WebVTT file its Captions field names, as the track elements a
	 * video block carries: the file, a label, its language and its kind.
	 *
	 * @since 4.33.0
	 *
	 * @param int $video_id The video attachment.
	 * @return array[] One captions track, or none.
	 */
	public static function captions( int $video_id ): array {
		$id  = (int) get_post_meta( $video_id, Media::CAPTIONS_META, true );
		$src = $id ? wp_get_attachment_url( $id ) : '';
		if ( ! $src || 'text/vtt' !== (string) get_post_mime_type( $id ) ) {
			return array();
		}
		$lang = (string) get_bloginfo( 'language' );
		return array(
			array(
				'src'     => $src,
				'label'   => (string) get_the_title( $id ),
				'srclang' => '' !== $lang ? $lang : 'en',
				'kind'    => 'captions',
			),
		);
	}

	/**
	 * The text tracks a video block carries, as captions the player can show: the block's `tracks`
	 * attribute, which the editor fills from its Text tracks panel.
	 *
	 * @since 4.33.0
	 *
	 * @param array $tracks The attribute: each { src, label, srcLang, kind }.
	 * @return array[]
	 */
	public static function block_captions( array $tracks ): array {
		$out = array();
		foreach ( $tracks as $track ) {
			$src = is_array( $track ) ? (string) ( $track['src'] ?? '' ) : '';
			if ( '' === $src ) {
				continue;
			}
			$kind  = (string) ( $track['kind'] ?? 'subtitles' );
			$out[] = array(
				'src'     => $src,
				'label'   => (string) ( $track['label'] ?? '' ),
				'srclang' => (string) ( $track['srcLang'] ?? $track['srclang'] ?? '' ),
				'kind'    => in_array( $kind, array( 'captions', 'subtitles', 'descriptions' ), true ) ? $kind : 'subtitles',
			);
		}
		return $out;
	}

	/**
	 * Builds a track from a file that is not in the Media Library, such as an audio block that
	 * points at another site. All Riff knows is the address, the caption, and the post.
	 *
	 * @since 4.0.0
	 * @param string $src     Media URL.
	 * @param string $type    'audio' or 'video'.
	 * @param string $caption The block's caption, used as the title when there is one.
	 * @param int    $post_id The post the track appears in.
	 * @return array|null
	 */
	public static function from_url( string $src, string $type, string $caption = '', int $post_id = 0 ): ?array {
		$src = esc_url_raw( $src );
		if ( ! $src || ( 'audio' !== $type && 'video' !== $type ) ) {
			return null;
		}
		$title = trim( $caption );
		if ( '' === $title ) {
			$title = rawurldecode( pathinfo( (string) wp_parse_url( $src, PHP_URL_PATH ), PATHINFO_FILENAME ) );
		}
		return self::filter(
			array(
				'id'       => 'url:' . md5( $src ),
				'src'      => $src,
				'type'     => $type,
				'title'    => $title,
				'artist'   => '',
				'album'    => '',
				'lang'     => '',
				'year'     => 0,
				'disc'     => 0,
				'duration' => 0,
				'format'   => '',
				'bitrate'  => 0,
				'lossless' => false,
				'bits'     => 0,
				'rate'     => 0,
				'levels'   => '',
				'art'      => self::post_art( $post_id ),
				'captions' => array(),
				'video'    => null,
				'post'     => self::post( $post_id ),
			),
			0,
			$post_id
		);
	}

	/**
	 * Hands a finished track to the site.
	 *
	 * @param array $track         Track.
	 * @param int   $attachment_id Attachment ID, or 0 for a bare address.
	 * @param int   $post_id       Post ID, or 0.
	 * @return array
	 */
	private static function filter( array $track, int $attachment_id, int $post_id ): array {
		/**
		 * Filters a track before the player reads it.
		 *
		 * @since 4.0.0
		 *
		 * @param array $track         Track: id, src, type, title, artist, album, duration, art, video, post.
		 * @param int   $attachment_id Attachment ID, or 0 for a file outside the Media Library.
		 * @param int   $post_id       The post the track appears in, or 0.
		 */
		$track = self::normalize( (array) apply_filters( 'riff_track', $track, $attachment_id, $post_id ) );
		return self::gate( $track, $attachment_id, $post_id );
	}

	/**
	 * Locks a track the current visitor may not play: it keeps its title, artist and artwork, so
	 * lists and their counts stay the same, and loses its file and its video, so nothing plays it.
	 *
	 * The address of a locked file still works for anyone who has it, as every upload's does; this
	 * keeps it out of what Riff writes on the page and returns over REST.
	 *
	 * @since 4.17.0
	 *
	 * @param array $track         Track.
	 * @param int   $attachment_id Attachment ID, or 0 for a bare address.
	 * @param int   $post_id       Post ID, or 0.
	 * @return array
	 */
	private static function gate( array $track, int $attachment_id, int $post_id ): array {
		/**
		 * Filters whether the current visitor may play a track.
		 *
		 * A membership or store plugin returns false for a track its rules keep from this visitor.
		 * The track is then listed as locked rather than hidden, with no file to play.
		 *
		 * @since 4.17.0
		 *
		 * @param bool  $allowed       Whether the track plays. Default true.
		 * @param array $track         Track, after riff_track.
		 * @param int   $attachment_id Attachment ID, or 0 for a file outside the Media Library.
		 * @param int   $post_id       The post the track appears in, or 0.
		 */
		if ( ! (bool) apply_filters( 'riff_can_play', true, $track, $attachment_id, $post_id ) ) {
			return self::lock( $track, $attachment_id, $post_id );
		}
		if ( ! $attachment_id ) {
			return $track;
		}
		// The one gate every play goes through, with where it is asked and the pass it carries.
		$context = array(
			'pass' => Rights::pass(),
			'via'  => Rights::via(),
			'post' => $post_id,
		);
		$allowed = Rights::may_play( $attachment_id, get_current_user_id(), $context );
		if ( true !== $allowed ) {
			return self::lock( $track, $attachment_id, $post_id, $allowed->get_error_message() );
		}
		$track['src'] = Rights::play_url( $track['src'], $attachment_id, $context );
		return $track;
	}

	/**
	 * A track with its file and video taken away, listed with where to unlock it.
	 *
	 * @param array  $track         Track.
	 * @param int    $attachment_id Attachment ID, or 0 for a bare address.
	 * @param int    $post_id       Post ID, or 0.
	 * @param string $reason        Why, for the listener, or empty.
	 * @return array
	 */
	private static function lock( array $track, int $attachment_id, int $post_id, string $reason = '' ): array {
		/**
		 * Filters where a locked track sends the visitor to unlock it: a sign-up, membership or
		 * checkout page.
		 *
		 * @since 4.17.0
		 *
		 * @param string $url           Address, or empty for none. Default empty.
		 * @param array  $track         Track.
		 * @param int    $attachment_id Attachment ID, or 0.
		 * @param int    $post_id       The post the track appears in, or 0.
		 */
		$unlock          = (string) apply_filters( 'riff_unlock_url', '', $track, $attachment_id, $post_id );
		$track['src']    = '';
		$track['video']  = null;
		$track['locked'] = true;
		$track['unlock'] = esc_url_raw( $unlock );
		$track['reason'] = sanitize_text_field( $reason );
		return $track;
	}

	/**
	 * The version of the track shape. It changes only with a major release, and every consumer
	 * (REST, GraphQL, the block attribute, riff.js) reads the same shape.
	 *
	 * @since 4.0.0
	 */
	public const SCHEMA_VERSION = 1;

	/**
	 * The track shape as JSON Schema, shared by REST and GraphQL.
	 *
	 * @since 4.0.0
	 *
	 * @return array
	 */
	public static function schema(): array {
		return array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'riff-track',
			'type'       => 'object',
			'properties' => array(
				'id'        => array(
					'type'        => 'string',
					'description' => __( 'The attachment ID, or "url:" and a hash for a file outside the Media Library.', 'riff' ),
				),
				'src'       => array(
					'type'   => 'string',
					'format' => 'uri',
				),
				'type'      => array(
					'type' => 'string',
					'enum' => array( 'audio', 'video' ),
				),
				'title'     => array( 'type' => 'string' ),
				'artist'    => array( 'type' => 'string' ),
				'album'     => array( 'type' => 'string' ),
				'year'      => array(
					'type'        => 'integer',
					'description' => __( 'The year from the file\'s tags, or 0.', 'riff' ),
				),
				'disc'      => array(
					'type'        => 'integer',
					'description' => __( 'Which disc of a set the track is on, from the file\'s disc number tag (1 for "1/2"), or 0 when the tags do not say.', 'riff' ),
				),
				'duration'  => array(
					'type'        => 'number',
					'description' => __( 'Seconds, 0 when unknown.', 'riff' ),
				),
				'lang'      => array(
					'type'        => 'string',
					'description' => __( 'The language of the title and artist, as a lang attribute takes it, from the file\'s tags; empty when the file does not say.', 'riff' ),
				),
				'format'    => array(
					'type'        => 'string',
					'description' => __( 'The container, lower case, as WordPress read it from the file: mp3, flac, m4a. Empty when unknown.', 'riff' ),
				),
				'bitrate'   => array(
					'type'        => 'integer',
					'description' => __( 'Kilobits per second, 0 when unknown.', 'riff' ),
				),
				'lossless'  => array(
					'type'        => 'boolean',
					'description' => __( 'Whether the encoding is lossless.', 'riff' ),
				),
				'bits'      => array(
					'type'        => 'integer',
					'description' => __( 'Bits per sample, as WordPress read it from the file; 0 when the format does not say, as MP3 does not.', 'riff' ),
				),
				'rate'      => array(
					'type'        => 'integer',
					'description' => __( 'Samples per second, 0 when unknown.', 'riff' ),
				),
				'levels'    => array(
					'type'        => 'string',
					'description' => __( 'The track\'s loudness over time as digits 0 to 9, one per sample, when something has measured it; the drawn cover puts it in the groove. Empty otherwise.', 'riff' ),
				),
				'art'       => array(
					'type'        => 'array',
					'description' => __( 'Artwork, smallest first.', 'riff' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'src'   => array( 'type' => 'string' ),
							'sizes' => array( 'type' => 'string' ),
							'alt'   => array(
								'type'        => 'string',
								'description' => __( 'What the picture shows, for a screen reader: the image\'s alt text, or the album and artist a drawn cover names.', 'riff' ),
							),
						),
					),
				),
				'captions'  => array(
					'type'        => 'array',
					'description' => __( 'Text tracks for a video: the WebVTT file its Captions field names, or the tracks its video block carries.', 'riff' ),
					'items'       => self::captions_schema(),
				),
				'video'     => array(
					'type'       => array( 'object', 'null' ),
					'properties' => array(
						'src'      => array( 'type' => 'string' ),
						'poster'   => array( 'type' => 'string' ),
						'captions' => array(
							'type'  => 'array',
							'items' => self::captions_schema(),
						),
					),
				),
				'post'      => array(
					'type'       => array( 'object', 'null' ),
					'properties' => array(
						'id'      => array( 'type' => 'integer' ),
						'title'   => array( 'type' => 'string' ),
						'url'     => array( 'type' => 'string' ),
						'private' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether the post is one visitors can\'t see, unpublished or behind a password. Only ever true for someone signed in who may see it.', 'riff' ),
						),
					),
				),
				'rights'    => array(
					'type'        => array( 'object', 'null' ),
					'description' => __( 'The rights the artist set on the track or its album, from riff_rights; null while nothing is set.', 'riff' ),
					'properties'  => array(
						'holder'        => array( 'type' => 'string' ),
						'year'          => array(
							'type'        => 'integer',
							'description' => __( 'The year for the ℗ line, or 0.', 'riff' ),
						),
						'license'       => array( 'type' => 'string' ),
						'license_url'   => array(
							'type'        => 'string',
							'description' => __( 'The licence\'s deed, or empty for all rights reserved.', 'riff' ),
						),
						'license_label' => array( 'type' => 'string' ),
						'isrc'          => array( 'type' => 'string' ),
						'attested'      => array(
							'type'        => 'boolean',
							'description' => __( 'Whether the uploader stated they own or control the rights.', 'riff' ),
						),
					),
				),
				'downloads' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether the current visitor may download the file, from riff_may_download.', 'riff' ),
				),
				'links'     => array(
					'type'        => 'array',
					'description' => __( 'Links a host adds to the track\'s info, from riff_item_links: a report link, say. Empty by default.', 'riff' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'label' => array( 'type' => 'string' ),
							'url'   => array( 'type' => 'string' ),
						),
					),
				),
				'locked'    => array(
					'type'        => 'boolean',
					'description' => __( 'Whether the current visitor may not play the track, as riff_can_play decided. A locked track has no src.', 'riff' ),
				),
				'unlock'    => array(
					'type'        => 'string',
					'description' => __( 'Where a locked track sends the visitor to unlock it, from riff_unlock_url. Empty otherwise.', 'riff' ),
				),
				'reason'    => array(
					'type'        => 'string',
					'description' => __( 'Why a locked track is locked, for the listener, from riff_may_play: "No longer available" for one past its availability. Empty otherwise.', 'riff' ),
				),
			),
		);
	}

	/**
	 * The shape of one text track.
	 *
	 * @return array
	 */
	private static function captions_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'src'     => array( 'type' => 'string' ),
				'label'   => array( 'type' => 'string' ),
				'srclang' => array( 'type' => 'string' ),
				'kind'    => array(
					'type' => 'string',
					'enum' => array( 'captions', 'subtitles', 'descriptions' ),
				),
			),
		);
	}

	/**
	 * Holds a track to its shape after a filter has had it: every key present with the right type,
	 * extra keys kept for whoever added them. A track that lost its source is returned without one
	 * and the player skips it.
	 *
	 * @since 4.0.0
	 *
	 * @param array $track Track, as filtered.
	 * @return array
	 */
	public static function normalize( array $track ): array {
		$track['id']       = (string) ( $track['id'] ?? '' );
		$track['src']      = is_string( $track['src'] ?? null ) ? $track['src'] : '';
		$track['type']     = 'video' === ( $track['type'] ?? '' ) ? 'video' : 'audio';
		$track['title']    = (string) ( $track['title'] ?? '' );
		$track['artist']   = (string) ( $track['artist'] ?? '' );
		$track['album']    = (string) ( $track['album'] ?? '' );
		$track['lang']     = Media::language_code( (string) ( $track['lang'] ?? '' ) );
		$track['year']     = max( 0, (int) ( $track['year'] ?? 0 ) );
		$track['disc']     = max( 0, (int) ( $track['disc'] ?? 0 ) );
		$track['duration'] = (float) max( 0, (float) ( $track['duration'] ?? 0 ) );
		$track['format']   = strtolower( (string) ( $track['format'] ?? '' ) );
		$track['bitrate']  = max( 0, (int) ( $track['bitrate'] ?? 0 ) );
		$track['lossless'] = ! empty( $track['lossless'] );
		$track['bits']     = max( 0, (int) ( $track['bits'] ?? 0 ) );
		$track['rate']     = max( 0, (int) ( $track['rate'] ?? 0 ) );
		$track['levels']   = is_string( $track['levels'] ?? null ) ? preg_replace( '/[^0-9]/', '', $track['levels'] ) : '';
		$track['art']      = array_values(
			array_filter(
				(array) ( $track['art'] ?? array() ),
				static fn( $a ) => is_array( $a ) && ! empty( $a['src'] )
			)
		);
		$track['captions'] = self::block_captions( (array) ( $track['captions'] ?? array() ) );
		$track['video']    = is_array( $track['video'] ?? null ) && ! empty( $track['video']['src'] ) ? $track['video'] : null;
		if ( $track['video'] ) {
			$track['video']['captions'] = self::block_captions( (array) ( $track['video']['captions'] ?? array() ) );
		}
		$track['post'] = is_array( $track['post'] ?? null ) && ! empty( $track['post']['url'] ) ? $track['post'] : null;
		if ( $track['post'] ) {
			$track['post']['private'] = ! empty( $track['post']['private'] );
		}
		$track['locked']    = ! empty( $track['locked'] );
		$track['unlock']    = is_string( $track['unlock'] ?? null ) ? $track['unlock'] : '';
		$track['reason']    = $track['locked'] && is_string( $track['reason'] ?? null ) ? $track['reason'] : '';
		$track['rights']    = is_array( $track['rights'] ?? null ) ? $track['rights'] : null;
		$track['downloads'] = ! array_key_exists( 'downloads', $track ) || ! empty( $track['downloads'] );
		$track['links']     = Rights::clean_links( $track['links'] ?? array() );
		return $track;
	}

	/**
	 * The disc a file's tags put it on: the first number of "1/2" or "1", or 0.
	 *
	 * @param mixed $tag The part_of_a_set tag, as getID3 read it.
	 * @return int
	 */
	private static function disc( $tag ): int {
		$tag = is_array( $tag ) ? reset( $tag ) : $tag;
		return is_scalar( $tag ) && preg_match( '/^\s*(\d+)/', (string) $tag, $m ) ? (int) $m[1] : 0;
	}

	/**
	 * A post's own image. A cover drawn in its place is the Listen feature's, through riff_track.
	 *
	 * @since 4.0.0
	 * @param int $post_id Post ID, or 0.
	 * @return array List of { src, sizes }.
	 */
	private static function post_art( int $post_id ): array {
		if ( ! $post_id ) {
			return array();
		}
		return self::art( (int) get_post_thumbnail_id( $post_id ) );
	}

	/**
	 * Reads the track out of a block's markup: its attachment when it has one, the file address
	 * otherwise.
	 *
	 * @param string $html    The block's markup, rendered or as saved.
	 * @param array  $attrs   Block attributes.
	 * @param string $type    'audio' or 'video'.
	 * @param int    $post_id Post ID.
	 * @return array|null
	 */
	public static function from_markup( string $html, array $attrs, string $type, int $post_id ): ?array {
		if ( ! empty( $attrs['id'] ) ) {
			$track = self::from_attachment( (int) $attrs['id'], $post_id );
			if ( $track ) {
				return $track;
			}
		}

		$tags = new WP_HTML_Tag_Processor( $html );
		if ( ! $tags->next_tag( $type ) ) {
			return null;
		}
		$src = $tags->get_attribute( 'src' );
		if ( ! is_string( $src ) || '' === $src ) {
			return null;
		}
		$caption = preg_match( '#<figcaption[^>]*>(.*?)</figcaption>#s', $html, $m ) ? wp_strip_all_tags( $m[1] ) : '';
		return self::from_url( $src, $type, html_entity_decode( $caption, ENT_QUOTES, 'UTF-8' ), $post_id );
	}

	/**
	 * Reads the track out of a parsed block.
	 *
	 * @since 4.0.0
	 * @param array $block   Parsed block, from parse_blocks().
	 * @param int   $post_id Post ID.
	 * @return array|null
	 */
	public static function from_block( array $block, int $post_id ): ?array {
		$name  = (string) ( $block['blockName'] ?? '' );
		$attrs = (array) ( $block['attrs'] ?? array() );
		if ( 'core/playlist-track' === $name ) {
			// A playlist's track is an attachment by id, with the file's tags copied onto the block
			// when it was picked. The attachment is read, so later edits to its tags and artwork show;
			// a track whose file has since gone is skipped, as core skips it.
			$id = (int) ( $attrs['id'] ?? 0 );
			return $id ? self::from_attachment( $id, $post_id ) : null;
		}
		$type  = 'core/video' === $name ? 'video' : 'audio';
		$track = self::from_markup( (string) ( $block['innerHTML'] ?? '' ), $attrs, $type, $post_id );
		// A video block's own text tracks, from its Text tracks panel, when the file has none of its own.
		if ( $track && 'video' === $type && empty( $track['captions'] ) && ! empty( $attrs['tracks'] ) && is_array( $attrs['tracks'] ) ) {
			$track['captions'] = self::block_captions( $attrs['tracks'] );
		}
		return $track;
	}

	/**
	 * The attachment's title, unless it is still the file's name and the file's own tags know
	 * better. The block editor and the REST API name an upload after its file; only the classic
	 * uploader reads the tags. A title somebody has edited is left alone. With no title anywhere,
	 * the file's name stands in, as the Media Library shows it, so a row is never blank.
	 *
	 * @since 4.0.0
	 * @since 4.32.0 An untitled track is named after its file.
	 * @param int   $attachment_id Attachment ID.
	 * @param array $meta          Attachment metadata, which carries the tags for audio.
	 * @return string
	 */
	private static function title( int $attachment_id, array $meta ): string {
		$title = trim( (string) get_post_field( 'post_title', $attachment_id, 'raw' ) );
		$file  = (string) get_attached_file( $attachment_id );
		if ( '' === $file ) {
			$file = (string) wp_parse_url( (string) wp_get_attachment_url( $attachment_id ), PHP_URL_PATH );
		}
		$stem = $file ? rawurldecode( pathinfo( $file, PATHINFO_FILENAME ) ) : '';
		// Compared loosely: the factory, the editor and a hand upload each punctuate the name differently.
		// Letters and digits in any script: a Cyrillic or Japanese title must not collapse to nothing.
		$named = static fn( string $s ): string => mb_strtolower( (string) preg_replace( '/[^\p{L}\p{N}]+/u', '', (string) preg_replace( '/\.[a-z0-9]{2,4}$/i', '', $s ) ) );
		// A second upload of the same name gets "-1" on the file but not on the title.
		$stems = array_map( $named, array( $stem, (string) preg_replace( '/-\d+$/', '', $stem ) ) );
		if ( ! empty( $meta['title'] ) && is_scalar( $meta['title'] ) && '' !== trim( (string) $meta['title'] ) && ( '' === $title || in_array( $named( $title ), $stems, true ) ) ) {
			$title = trim( (string) $meta['title'] );
		}
		if ( '' === $title ) {
			$title = $stem;
		}
		return html_entity_decode( $title, ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * The video version of an audio track.
	 *
	 * @param int   $video_id Video attachment ID.
	 * @param array $art      The audio track's artwork, used as the poster when the video has none.
	 * @return array|null
	 */
	private static function video( int $video_id, array $art ): ?array {
		if ( ! str_starts_with( (string) get_post_mime_type( $video_id ), 'video/' ) ) {
			return null;
		}
		$src = wp_get_attachment_url( $video_id );
		if ( ! $src ) {
			return null;
		}
		$poster = self::art( (int) get_post_thumbnail_id( $video_id ) );
		$poster = $poster ? $poster : $art;
		return array(
			'src'      => $src,
			'poster'   => $poster ? end( $poster )['src'] : '',
			'captions' => self::captions( $video_id ),
		);
	}

	/**
	 * Artwork in every registered size the image has, smallest first, each with the image's alt
	 * text from the Media Library, as the Image block takes it.
	 *
	 * A size WordPress didn't make, for an image smaller than it or one uploaded while the size was
	 * turned off, is the original under that size's name, shrunk only in its numbers. It is offered
	 * at its own size, so a srcset never takes a large original for a small copy.
	 *
	 * @since 4.33.0 Each size carries the image's alt text.
	 * @since 5.8.0 The original at its own size, in its place by width.
	 *
	 * @param int $image_id Image attachment ID, or 0.
	 * @return array List of { src, sizes, alt }.
	 */
	public static function art( int $image_id ): array {
		if ( ! $image_id ) {
			return array();
		}
		$art  = array();
		$seen = array();
		$alt  = trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
		$full = wp_get_attachment_image_src( $image_id, 'full' );
		foreach ( self::ART_SIZES as $size ) {
			$image = wp_get_attachment_image_src( $image_id, $size );
			if ( ! $image || isset( $seen[ $image[0] ] ) ) {
				continue;
			}
			if ( $full && $full[0] === $image[0] ) {
				$image = $full;
			}
			$seen[ $image[0] ] = true;
			$art[]             = array(
				'src'   => $image[0],
				'sizes' => $image[1] . 'x' . $image[2],
				'alt'   => $alt,
			);
		}
		usort( $art, static fn( array $a, array $b ): int => (int) $a['sizes'] <=> (int) $b['sizes'] );
		return $art;
	}

	/**
	 * Where a track was found, for "Playing from".
	 *
	 * @param int $post_id Post ID, or 0.
	 * @return array|null
	 */
	private static function post( int $post_id ): ?array {
		if ( ! $post_id ) {
			return null;
		}
		return array(
			'id'      => $post_id,
			'title'   => Library::title( $post_id ),
			'url'     => (string) get_permalink( $post_id ),
			'private' => Library::is_private( $post_id ),
		);
	}
}
