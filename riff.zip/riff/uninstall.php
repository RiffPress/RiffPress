<?php
/**
 * Removes what Riff stored about the library: the video and streaming-version links on audio
 * files, what the import and the catalogue noted on them, the tint taken from each post's cover,
 * and the album and artist terms. The files, their tags
 * and their featured images are WordPress's own and stay. So does what listeners made, their
 * playlists, likes and recently played, which would be cumbersome to make again after a reinstall;
 * Tools > Erase Personal Data deletes one listener's.
 *
 * @package Riff
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Protected files go back where they were, and the posts that named them are relinked, so nothing
// points at an address that stops working with the plugin gone.
$riff_base  = trailingslashit( wp_upload_dir( null, false )['basedir'] );
$riff_moved = array();
foreach ( get_posts(
	array(
		'post_type'      => 'attachment',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'meta_key'       => '_riff_protected', // phpcs:ignore WordPress.DB.SlowDBQuery -- uninstall, once.
	)
) as $riff_id ) {
	$riff_file = (string) get_attached_file( $riff_id, true );
	// A move to a new protected folder cut short after the file went and before WordPress was told.
	$riff_moving = (string) get_post_meta( $riff_id, '_riff_protected_moving', true );
	if ( ! is_file( $riff_file ) && '' !== $riff_moving && is_file( $riff_moving ) ) {
		$riff_file = $riff_moving;
	}
	$riff_to = $riff_base . ltrim( (string) get_post_meta( $riff_id, '_riff_protected', true ), '/' );
	if ( file_exists( $riff_to ) ) {
		$riff_to = dirname( $riff_to ) . '/' . wp_unique_filename( dirname( $riff_to ), basename( $riff_to ) );
	}
	// isolation: write -- a protected file back where it was under uploads.
	wp_mkdir_p( dirname( $riff_to ) );
	if ( is_file( $riff_file ) && @rename( $riff_file, $riff_to ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.rename_rename -- isolation: write -- back under uploads.
		update_attached_file( $riff_id, $riff_to );
		$riff_moved[ add_query_arg( 'riff-file', $riff_id, home_url( '/' ) ) ] = (string) wp_get_attachment_url( $riff_id );
	}
}
// Every moved file's posts at once, as a search through every post can't use an index.
if ( ! empty( $riff_moved ) ) {
	if ( ! class_exists( 'Riff\Protected_Files' ) ) {
		require_once __DIR__ . '/src/class-protected-files.php';
	}
	Riff\Protected_Files::relink_all( $riff_moved );
}
delete_option( 'riff_protected_dir' );
delete_option( 'riff_protected_folders' );
delete_option( 'riff_protected_move_state' );
delete_option( 'riff_protected_move_lock' );
delete_transient( 'riff_protected_open' );
wp_clear_scheduled_hook( 'riff_protected_move' );
wp_clear_scheduled_hook( 'riff_protected_probe' );
delete_option( 'riff_private' );
wp_clear_scheduled_hook( 'riff_private_sweep' );
// The settings on Settings › Riff: the assistant's tools, links that keep the music playing, and
// the app at the site's address.
delete_option( 'riff_mcp' );
delete_option( 'riff_client_navigation' );
delete_option( 'riff_app_at_root' );

foreach ( array( '_riff_private', '_riff_protected', '_riff_protected_moving', '_riff_video', '_riff_stream', '_riff_import_hash', '_riff_import_folder', '_riff_catalog', '_riff_tint' ) as $riff_key ) {
	delete_post_meta_by_key( $riff_key );
}

foreach ( array( 'riff_album', 'riff_artist' ) as $riff_taxonomy ) {
	// The plugin is not loaded here, so the taxonomy is registered just long enough to delete its terms.
	register_taxonomy( $riff_taxonomy, 'attachment' );
	$riff_terms = $wpdb->get_col( $wpdb->prepare( "SELECT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s", $riff_taxonomy ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- uninstall, once.
	foreach ( $riff_terms as $riff_term ) {
		wp_delete_term( (int) $riff_term, $riff_taxonomy );
	}
}
// The drawn covers kept in uploads, drawn again by nothing once Riff is gone.
foreach ( (array) glob( $riff_base . 'riff-art/*', GLOB_ONLYDIR ) as $riff_dir ) {
	array_map( 'wp_delete_file', (array) glob( $riff_dir . '/*' ) );
	@rmdir( $riff_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- uninstall, once.
}
@rmdir( $riff_base . 'riff-art' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- uninstall, once.
delete_option( 'riff_art_stamp' );
delete_option( 'riff_art_changed' );
delete_option( 'riff_turntable' );
delete_option( 'riff_extensions' );
delete_site_option( 'riff_extensions_network' );
delete_option( 'riff_catalog_backfill' );
delete_option( 'riff_catalog_backfill_from' );
delete_option( 'riff_rewrite' );
delete_transient( 'riff_listen_page' );
// What Riff\Cache kept between requests, and the stamp that says whether it is still current. Each
// kept value's transient is named by a hash of what it holds, so they go by their prefix. With a
// persistent object cache they are in that cache instead, and expire within a day.
delete_option( 'riff_changed' );
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_riff_kept_' ) . '%', $wpdb->esc_like( '_transient_timeout_riff_kept_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- uninstall, once; transients named by a hash have no API to list them.
wp_clear_scheduled_hook( 'riff_catalog_backfill' );
wp_unschedule_hook( 'riff_import_zip' );

// Who dismissed the first-run notice: a user option, so its key carries the site's table prefix.
delete_metadata( 'user', 0, $wpdb->get_blog_prefix() . 'riff_first_run_dismissed', '', true );
// A listener's choices, also user options: the single-key shortcuts turned off, and whether they
// show others what they are listening to. Their likes and recently played stay, as above.
delete_metadata( 'user', 0, $wpdb->get_blog_prefix() . 'riff_shortcuts', '', true );
delete_metadata( 'user', 0, $wpdb->get_blog_prefix() . 'riff_together_share', '', true );
